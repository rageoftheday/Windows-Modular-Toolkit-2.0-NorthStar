@echo off
title Comp Store
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
