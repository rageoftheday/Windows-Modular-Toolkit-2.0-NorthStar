Comp Store

Rebuilt from original label :comp_store.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
