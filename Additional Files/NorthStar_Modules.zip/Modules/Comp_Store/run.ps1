# ============================================================
# COMP STORE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "COMP STORE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Windows Component Store Analysis:'
    Write-Host '  Analyses the WinSxS component store which holds Windows'
    Write-Host '  update and feature files. This folder appears large but'
    Write-Host '  much of it is hard-linked. DISM can clean it up safely.'
    Write-Host '  Run this before using DISM cleanup to see current state.'
    Write-Host ""
    cmd.exe /c "dism /online /cleanup-image /analyzecomponentstore"
    Write-Host ""
    Write-Host 'TIP: To clean the component store run:'
    Write-Host '     dism /online /cleanup-image /startcomponentcleanup'
    Write-Host ""

}
