@echo off
title WMI Check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
