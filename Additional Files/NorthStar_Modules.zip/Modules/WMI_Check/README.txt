WMI Check

Rebuilt from original label :wmi_check.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
