# ============================================================
# WMI CHECK
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WMI CHECK" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Verifying and repairing WMI Repository if needed...'
    Write-Host '  WMI is the Windows system that tools use to read'
    Write-Host '  hardware and software information. If broken, many'
    Write-Host '  diagnostics in this toolkit will return no data.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'wmicheck.ps1'
    Set-Content -Path $f -Value '$result = (winmgmt /verifyrepository 2>$null)' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host $result' -Encoding UTF8
    Add-Content -Path $f -Value 'if ($result -notmatch ''consistent'') {' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''Result indicates repository may not be consistent.'' -ForegroundColor Yellow' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''Attempting salvage repair...'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'winmgmt /salvagerepository' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''Salvage complete. Run Section 0 the appropriate validator module for a full repair if issues persist.'' -ForegroundColor Yellow' -Encoding UTF8
    Add-Content -Path $f -Value '} else {' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''WMI repository is consistent. No repair needed.'' -ForegroundColor Green' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    cmd.exe /c "if errorlevel 1 echo [FAIL] PowerShell execution failed"
    Write-Host ""
    Write-Host 'WMI check complete. For a full repair use Section 0 the appropriate validator module.'
    Write-Host ""

}
