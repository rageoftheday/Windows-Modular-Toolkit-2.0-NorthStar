@echo off
title Powershell App Crash
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
