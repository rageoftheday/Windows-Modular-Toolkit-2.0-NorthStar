Powershell App Crash

Rebuilt from original label :ps_app_crash.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
