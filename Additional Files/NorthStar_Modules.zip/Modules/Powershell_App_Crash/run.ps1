# ============================================================
# POWERSHELL APP CRASH
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL APP CRASH" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "APP CRASH EVENTS"

    Write-Host "Shows recent application crash events."
    Write-Host ""

    Get-WinEvent -FilterHashtable @{
        LogName = "Application"
        Id      = 1000
    } -MaxEvents 25 -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, ProviderName, Id, Message |
        Format-List

    Write-Host ""
    Pause-Toolkit
}
