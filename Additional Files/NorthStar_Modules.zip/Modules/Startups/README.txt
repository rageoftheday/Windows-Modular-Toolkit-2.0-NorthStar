Startups

Rebuilt from original label :startups.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
