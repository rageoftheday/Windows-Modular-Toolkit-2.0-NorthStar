# ============================================================
# STARTUPS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "STARTUPS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Startup Items:'
    Write-Host '  Shows everything configured to run when Windows starts.'
    Write-Host '  Useful for diagnosing slow startup times or finding'
    Write-Host '  unwanted programs launching automatically.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'startups.ps1'
    Set-Content -Path $f -Value 'Get-CimInstance Win32_StartupCommand | Format-Table Name,Command,Location -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host 'TIP: To manage startup items interactively, use Task Manager'
    Write-Host '     (Ctrl+Shift+Esc) then click the Startup tab.'
    Write-Host ""

}
