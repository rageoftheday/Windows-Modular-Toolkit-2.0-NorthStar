@echo off
title Startups
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
