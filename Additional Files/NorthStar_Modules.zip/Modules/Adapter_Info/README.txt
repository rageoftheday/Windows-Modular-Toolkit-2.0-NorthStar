Adapter Info

Rebuilt from original label :adapter_info.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
