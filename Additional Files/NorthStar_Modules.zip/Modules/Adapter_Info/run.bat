@echo off
title Adapter Info
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
