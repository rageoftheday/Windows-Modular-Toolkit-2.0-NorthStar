# ============================================================
# ADAPTER INFO
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "ADAPTER INFO" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Network Adapter Details:'
    Write-Host '  Shows all network adapters with their speed, MAC address,'
    Write-Host '  duplex setting, and status. Useful for confirming a NIC'
    Write-Host '  is running at the expected speed (e.g. 1Gbps not 100Mbps).'
    Write-Host ""
    $f = Join-Path $env:TEMP 'adapterinfo.ps1'
    Set-Content -Path $f -Value 'Get-NetAdapter | Select-Object Name,InterfaceDescription,MacAddress,LinkSpeed,FullDuplex,Status | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
