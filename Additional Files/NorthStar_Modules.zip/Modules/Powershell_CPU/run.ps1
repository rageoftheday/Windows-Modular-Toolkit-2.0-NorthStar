# ============================================================
# POWERSHELL CPU
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL CPU" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'CPU Information:'
    Write-Host '  Detailed CPU info including core count, logical processors'
    Write-Host '  (threads), clock speed, and current load percentage.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'cpuinfo.ps1'
    Set-Content -Path $f -Value 'Get-CimInstance Win32_Processor | Format-List Name,Manufacturer,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,CurrentClockSpeed,LoadPercentage,SocketDesignation' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
