@echo off
title Powershell CPU
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
