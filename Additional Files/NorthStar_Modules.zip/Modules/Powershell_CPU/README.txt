Powershell CPU

Rebuilt from original label :ps_cpu.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
