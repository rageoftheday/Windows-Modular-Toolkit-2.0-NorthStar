@echo off
title Domain Check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
