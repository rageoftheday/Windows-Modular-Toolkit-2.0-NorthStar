# ============================================================
# DOMAIN CHECK
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DOMAIN CHECK" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Domain and Domain Controller Connectivity:'
    Write-Host '  Checks domain membership and tests connectivity to the'
    Write-Host '  domain controller. If nltest fails, the machine may'
    Write-Host '  have lost its secure channel to the domain.'
    Write-Host ""
    Write-Host '--- Domain Membership ---'
    $f = Join-Path $env:TEMP 'domaincheck.ps1'
    Set-Content -Path $f -Value '$cs = Get-CimInstance Win32_ComputerSystem' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host (''Computer : '' + $cs.Name) -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host (''Domain   : '' + $cs.Domain) -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host (''Joined   : '' + $cs.PartOfDomain) -ForegroundColor Cyan' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host '--- DC Connectivity ---'
    cmd.exe /c "nltest /dsgetdc: 2>nul"
    Write-Host ""
    Write-Host '--- Secure Channel Status ---'
    cmd.exe /c "nltest /sc_verify: 2>nul"
    Write-Host ""
    Write-Host ""

}
