Domain Check

Rebuilt from original label :domain_check.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
