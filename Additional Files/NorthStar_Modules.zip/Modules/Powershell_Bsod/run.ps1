# ============================================================
# POWERSHELL BSOD
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL BSOD" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "SilentlyContinue"

    Write-Host "Checking recent BSOD / unexpected shutdown events..."
    Write-Host ""

    $Events = Get-WinEvent `
        -FilterHashtable @{
            LogName = "System"
            Id      = 41, 6008
        } `
        -MaxEvents 20

    if ($Events) {

        $Events |
            Select-Object `
                TimeCreated,
                Id,
                @{N="Summary";E={
                    if ($_.Message) {
                        $_.Message.Substring(0, [math]::Min(120, $_.Message.Length))
                    }
                    else {
                        "No message"
                    }
                }} |
            Format-Table -AutoSize -Wrap
    }
    else {
        Write-Host "No recent BSOD or unexpected shutdown events found." -ForegroundColor Green
    }

    Write-Host ""
}