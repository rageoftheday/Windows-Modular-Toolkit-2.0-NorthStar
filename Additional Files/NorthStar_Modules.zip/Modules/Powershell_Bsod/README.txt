Powershell Bsod

Rebuilt from original label :ps_bsod.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
