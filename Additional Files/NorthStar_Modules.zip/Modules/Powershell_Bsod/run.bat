@echo off
title Powershell Bsod
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
