Powershell DNS Cache

Rebuilt from original label :ps_dns_cache.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
