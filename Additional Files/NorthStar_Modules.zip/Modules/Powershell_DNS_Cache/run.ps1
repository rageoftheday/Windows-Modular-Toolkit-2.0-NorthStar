# ============================================================
# POWERSHELL DNS CACHE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL DNS CACHE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'DNS Client Cache Contents:'
    Write-Host '  Shows all cached DNS entries on this machine. If a'
    Write-Host '  website is resolving to the wrong IP, its entry may'
    Write-Host '  be stuck in this cache. Use Basic Tools DNS flush'
    Write-Host '  (the appropriate validator module) to clear it.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'dnscache.ps1'
    Set-Content -Path $f -Value 'Get-DnsClientCache | Format-Table Entry,RecordName,RecordType,TimeToLive,DataLength -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
