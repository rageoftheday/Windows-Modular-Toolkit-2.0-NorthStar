@echo off
title Powershell DNS Cache
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
