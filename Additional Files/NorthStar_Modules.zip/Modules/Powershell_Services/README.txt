Powershell Services

Rebuilt from original label :ps_services.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
