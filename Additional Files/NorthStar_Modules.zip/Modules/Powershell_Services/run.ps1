# ============================================================
# POWERSHELL SERVICES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL SERVICES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'All Services and Their Status:'
    Write-Host '  Complete list of every service - running, stopped,'
    Write-Host '  and disabled. StartType shows if a service is set to'
    Write-Host '  start automatically or manually.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'services.ps1'
    Set-Content -Path $f -Value 'Get-Service | Sort-Object Status,Name | Format-Table Name,DisplayName,Status,StartType -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
