@echo off
title Svc Pid Map
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
