Svc Pid Map

Rebuilt from original label :svc_pid_map.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
