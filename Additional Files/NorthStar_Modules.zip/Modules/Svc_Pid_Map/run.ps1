# ============================================================
# SVC PID MAP
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SVC PID MAP" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Running Services with PID Mapping:'
    Write-Host '  Shows every running service and which process ID (PID)'
    Write-Host '  it is running under. Useful when investigating a process'
    Write-Host '  in Task Manager and needing to know what service it is.'
    Write-Host ""
    cmd.exe /c "tasklist /svc"
    Write-Host ""
    Write-Host ""

}
