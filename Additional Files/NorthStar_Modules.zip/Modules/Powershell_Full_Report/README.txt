Powershell Full Report

Rebuilt from original label :ps_full_report.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
