@echo off
title Powershell Full Report
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
