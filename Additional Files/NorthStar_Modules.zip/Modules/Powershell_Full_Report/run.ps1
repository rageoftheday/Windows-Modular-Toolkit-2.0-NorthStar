# ============================================================
# POWERSHELL FULL REPORT
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL FULL REPORT" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $DateStamp = Get-Date -Format "yyyyMMdd_HHmm"
    $Report = Join-Path $env:USERPROFILE "Desktop\IT_Report_$DateStamp.txt"

    Write-Host "Creating full system report..."
    Write-Host "Target: $Report" -ForegroundColor Cyan
    Write-Host ""

    "======================================================" | Out-File $Report -Encoding UTF8
    "WINDOWS 11 IT TOOLKIT - FULL SYSTEM REPORT" | Out-File $Report -Append
    "Generated: $(Get-Date)" | Out-File $Report -Append
    "======================================================" | Out-File $Report -Append

    Write-Host "Gathering System Info..."
    "" | Out-File $Report -Append
    "--- SYSTEM INFO ---" | Out-File $Report -Append
    systeminfo | Out-File $Report -Append

    Write-Host "Gathering Disk Info..."
    "" | Out-File $Report -Append
    "--- DISK USAGE ---" | Out-File $Report -Append

    Get-PSDrive -PSProvider FileSystem |
        Where-Object { $_.Used -ne $null } |
        Select-Object `
            Name,
            @{N="Total(GB)";E={[math]::Round(($_.Used + $_.Free) / 1GB, 1)}},
            @{N="Used(GB)";E={[math]::Round($_.Used / 1GB, 1)}},
            @{N="Free(GB)";E={[math]::Round($_.Free / 1GB, 1)}} |
        Format-Table -AutoSize |
        Out-String |
        Out-File $Report -Append

    Write-Host "Gathering Network Config..."
    "" | Out-File $Report -Append
    "--- NETWORK CONFIG ---" | Out-File $Report -Append
    ipconfig /all | Out-File $Report -Append

    Write-Host "Gathering Installed Software..."
    "" | Out-File $Report -Append
    "--- INSTALLED SOFTWARE ---" | Out-File $Report -Append

    Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" `
        -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName } |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate |
        Sort-Object DisplayName |
        Format-Table -AutoSize |
        Out-String |
        Out-File $Report -Append

    Write-Host "Gathering Recent System Errors..."
    "" | Out-File $Report -Append
    "--- RECENT SYSTEM ERRORS ---" | Out-File $Report -Append

    Get-WinEvent `
        -FilterHashtable @{
            LogName = "System"
            Level   = 1, 2
        } `
        -MaxEvents 20 `
        -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, Id, ProviderName, Message |
        Format-Table -AutoSize -Wrap |
        Out-String |
        Out-File $Report -Append

    Write-Host ""
    Write-Host "Report complete." -ForegroundColor Green
    Write-Host "Saved to:"
    Write-Host $Report
    Write-Host ""
}