# ============================================================
# BCD VIEW
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "BCD VIEW" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Boot Configuration Data (BCD):'
    Write-Host '  Shows the Windows boot configuration - what OS entries'
    Write-Host '  exist, boot timeout, and active boot loader. Useful for'
    Write-Host '  diagnosing dual-boot issues or boot failures.'
    Write-Host '  Do NOT edit BCD entries unless you know what you are doing.'
    Write-Host ""
    cmd.exe /c "bcdedit"
    Write-Host ""
    Write-Host ""

}
