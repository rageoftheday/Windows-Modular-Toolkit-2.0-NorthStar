Bcd View

Rebuilt from original label :bcd_view.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
