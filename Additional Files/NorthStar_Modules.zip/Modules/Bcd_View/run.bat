@echo off
title Bcd View
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
