Clear Windows Temporary Files

Rebuilt from original label :clear_wtemp.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
