@echo off
title Clear Windows Temporary Files
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
