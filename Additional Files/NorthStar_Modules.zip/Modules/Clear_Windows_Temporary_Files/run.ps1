# ============================================================
# CLEAR WINDOWS TEMPORARY FILES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CLEAR WINDOWS TEMPORARY FILES" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Clearing C:\Windows\Temp...'
    Write-Host '  Removes system-level temporary files. Similar to user'
    Write-Host '  temp but for Windows and system processes.'
    cmd.exe /c "del /q /f /s `"C:\Windows\Temp\*`" >nul 2>&1"
    Write-Host 'Done.'
    Write-Host ""

}
