@echo off
title Setup Depcheck Full
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
