Setup Depcheck Full

Rebuilt from original label :setup_depcheck_full.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
