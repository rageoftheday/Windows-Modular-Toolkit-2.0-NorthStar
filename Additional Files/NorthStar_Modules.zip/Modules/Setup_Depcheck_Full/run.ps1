# ============================================================
# SETUP DEPCHECK FULL
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SETUP DEPCHECK FULL" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Running Full Dependency Check (all items)...'
    Write-Host ""
    $f = Join-Path $env:TEMP 'depcheck_full.ps1'
    cmd.exe /c "powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^"
    cmd.exe /c "`"$lines = @(`" ^"
    cmd.exe /c "`"  '$pass = 0; $fail = 0',`" ^"
    cmd.exe /c "`"  'function Show($label, $ok) {',`" ^"
    cmd.exe /c "`"  '  if ($ok) { Write-Host (\`"[PASS]  \`" + $label) -ForegroundColor Green; $script:pass++ }',`" ^"
    cmd.exe /c "`"  '  else     { Write-Host (\`"[FAIL]  \`" + $label) -ForegroundColor Red;  $script:fail++ }',`" ^"
    cmd.exe /c "`"  '}',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Write-Host \`" FULL DEPENDENCY CHECK\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- WINGET PACKAGES ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"winget available\`"        ([bool](Get-Command winget -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"LibreHardwareMonitor\`"    ([bool](Get-Command LibreHardwareMonitor -EA SilentlyContinue) -or (Test-Path \`"$env:ProgramFiles\LibreHardwareMonitor\LibreHardwareMonitor.exe\`"))',`" ^"
    cmd.exe /c "`"  'Show \`"Sysinternals (psexec)\`"   ([bool](Get-Command psexec -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Nmap\`"                    ([bool](Get-Command nmap -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Git\`"                     ([bool](Get-Command git -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"7-Zip\`"                   ([bool](Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -EA SilentlyContinue | Where-Object { $_.DisplayName -like \`"*7-Zip*\`" }))',`" ^"
    cmd.exe /c "`"  'Show \`"Notepad++\`"               (Test-Path \`"$env:ProgramFiles\Notepad++\notepad++.exe\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WinDirStat\`"              ([bool](Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*, HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* -EA SilentlyContinue | Where-Object { $_.DisplayName -like \`"*WinDirStat*\`" -or $_.PSChildName -like \`"*WinDirStat*\`" }))',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- POWERSHELL MODULES ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"PSWindowsUpdate\`"         ([bool](Get-Module PSWindowsUpdate -ListAvailable -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"ImportExcel\`"             ([bool](Get-Module ImportExcel -ListAvailable -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Carbon\`"                  ([bool](Get-Module Carbon -ListAvailable -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- RSAT TOOLS ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: AD DS Tools\`"       ((Get-WindowsCapability -Online -Name \`"Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: DNS Tools\`"         ((Get-WindowsCapability -Online -Name \`"Rsat.Dns.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: GP Management\`"     ((Get-WindowsCapability -Online -Name \`"Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: Hyper-V Tools\`"     ((Get-WindowsOptionalFeature -Online -FeatureName \`"Microsoft-Hyper-V-Management-Clients\`").State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- WINDOWS FEATURES ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"Hyper-V enabled\`"         ((Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -EA SilentlyContinue).State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WSL enabled\`"             ((Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -EA SilentlyContinue).State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- WMI HEALTH ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"WMI Service running\`"     ((Get-Service Winmgmt -EA SilentlyContinue).Status -eq \`"Running\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WMI Repository OK\`"       ((winmgmt /verifyrepository 2>`$null) -match \`"consistent\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: OS query works\`"     ([bool](Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: Disk query works\`"   ([bool](Get-CimInstance Win32_DiskDrive -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: RAM query works\`"    ([bool](Get-CimInstance Win32_PhysicalMemory -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: CPU query works\`"    ([bool](Get-CimInstance Win32_Processor -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  '$color = if ($fail -eq 0) { \`"Green\`" } else { \`"Yellow\`" }',`" ^"
    cmd.exe /c "`"  'Write-Host (\`" RESULT: {0} passed, {1} failed\`" -f $pass, $fail) -ForegroundColor $color',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'if ($fail -gt 0) { Write-Host \`" Run Section 0 options to fix any failures.\`" -ForegroundColor Yellow }',`" ^"
    cmd.exe /c "`"  'else             { Write-Host \`" All dependencies present. Toolkit ready.\`"   -ForegroundColor Green }'`" ^"
    cmd.exe /c "`"); Set-Content -Path '$f' -Value ($lines -join \`"`n\`") -Encoding UTF8`""
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
