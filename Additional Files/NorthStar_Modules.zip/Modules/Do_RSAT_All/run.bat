@echo off
title Do RSAT All
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
