Do RSAT All

Rebuilt from original label :do_rsat_all.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
