# ============================================================
# DO RSAT ALL
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DO RSAT ALL" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $Caps = @(
        "Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0",
        "Rsat.Dns.Tools~~~~0.0.1.0",
        "Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0",
        "Rsat.HyperV.Tools~~~~0.0.1.0"
    )

    $Total = $Caps.Count
    $Index = 0

    foreach ($Cap in $Caps) {

        $Index++
        $ShortName = ($Cap -split "~~~~")[0]

        Write-Host "[$Index/$Total] Checking: $ShortName" -ForegroundColor Cyan

        $State = (
            Get-WindowsCapability `
                -Online `
                -Name $Cap `
                -ErrorAction SilentlyContinue
        ).State

        if ($State -eq "Installed") {
            Write-Host "  [OK] Already installed." -ForegroundColor Green
            continue
        }

        Write-Host "  Installing $ShortName..." -ForegroundColor Yellow

        try {
            Add-WindowsCapability `
                -Online `
                -Name $Cap `
                -ErrorAction Stop | Out-Null

            Write-Host "  [OK] Installed." -ForegroundColor Green
        }
        catch {
            Write-Host "  [FAIL] $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    Write-Host ""
    Write-Host "RSAT install complete." -ForegroundColor Green
    Write-Host ""
}