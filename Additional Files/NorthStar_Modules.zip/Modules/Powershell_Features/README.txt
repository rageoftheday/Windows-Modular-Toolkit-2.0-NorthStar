Powershell Features

Rebuilt from original label :ps_features.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
