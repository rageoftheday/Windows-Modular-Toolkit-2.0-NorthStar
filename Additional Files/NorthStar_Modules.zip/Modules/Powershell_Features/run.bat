@echo off
title Powershell Features
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
