# ============================================================
# POWERSHELL FEATURES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL FEATURES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Windows Optional Features:'
    Write-Host '  Lists all Windows optional features and whether they'
    Write-Host '  are enabled or disabled. Useful for checking if a'
    Write-Host '  feature like Hyper-V, WSL, or IIS is turned on.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'features.ps1'
    Set-Content -Path $f -Value 'Get-WindowsOptionalFeature -Online | Sort-Object State,FeatureName | Format-Table FeatureName,State -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
