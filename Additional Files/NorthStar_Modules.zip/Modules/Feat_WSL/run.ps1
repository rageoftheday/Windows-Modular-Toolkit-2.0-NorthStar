# ============================================================
# FEAT WSL
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FEAT WSL" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "Enabling WSL feature..." -ForegroundColor Cyan
    Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -NoRestart
    Write-Host "WSL enable request completed. Reboot may be required."
}
