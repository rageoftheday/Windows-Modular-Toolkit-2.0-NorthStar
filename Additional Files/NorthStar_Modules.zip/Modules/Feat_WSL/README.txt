Feat WSL

Rebuilt from original label :feat_wsl.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
