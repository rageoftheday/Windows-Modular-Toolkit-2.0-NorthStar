@echo off
title Feat WSL
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
