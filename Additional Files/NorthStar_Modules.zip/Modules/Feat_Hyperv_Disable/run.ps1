# ============================================================
# FEAT HYPERV DISABLE
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FEAT HYPERV DISABLE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "Disabling Hyper-V..." -ForegroundColor Cyan
    Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -NoRestart
    Write-Host "Hyper-V disable request completed. Reboot may be required."
}
