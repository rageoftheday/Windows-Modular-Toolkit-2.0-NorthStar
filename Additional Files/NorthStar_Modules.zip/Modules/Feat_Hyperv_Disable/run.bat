@echo off
title Feat Hyperv Disable
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
