@echo off
title Setup Check Readonly
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
