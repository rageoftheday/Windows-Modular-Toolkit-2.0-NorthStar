Setup Check Readonly

Rebuilt from original label :setup_check_readonly.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
