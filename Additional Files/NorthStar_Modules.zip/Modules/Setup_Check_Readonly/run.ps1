# ============================================================
# SETUP CHECK READONLY
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SETUP CHECK READONLY" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Scanning installed tools (no changes will be made)...'
    Write-Host ""
    $f = Join-Path $env:TEMP 'depcheck_read.ps1'
    cmd.exe /c "powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^"
    cmd.exe /c "`"$lines = @(`" ^"
    cmd.exe /c "`"  'function Show($label, $ok) {',`" ^"
    cmd.exe /c "`"  '  if ($ok) { Write-Host (\`"[OK]  \`" + $label) -ForegroundColor Green }',`" ^"
    cmd.exe /c "`"  '  else     { Write-Host (\`"[--]  \`" + $label) -ForegroundColor Yellow }',`" ^"
    cmd.exe /c "`"  '}',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"=== WINGET PACKAGES ===\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Show \`"winget\`"               ([bool](Get-Command winget -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"LibreHardwareMonitor\`" ([bool](Get-Command LibreHardwareMonitor -ErrorAction SilentlyContinue) -or (Test-Path \`"$env:ProgramFiles\LibreHardwareMonitor\LibreHardwareMonitor.exe\`"))',`" ^"
    cmd.exe /c "`"  'Show \`"Sysinternals Suite\`"   ([bool](Get-Command psexec -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Nmap\`"                 ([bool](Get-Command nmap -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Git\`"                  ([bool](Get-Command git -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"7-Zip\`"                ([bool](Get-Command 7z -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Notepad++\`"            (Test-Path \`"$env:ProgramFiles\Notepad++\notepad++.exe\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WinDirStat\`"           (Test-Path \`"${env:ProgramFiles(x86)}\WinDirStat\windirstat.exe\`")',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  'Write-Host \`"=== POWERSHELL MODULES ===\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Show \`"PSWindowsUpdate\`"      ([bool](Get-Module PSWindowsUpdate -ListAvailable -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"ImportExcel\`"          ([bool](Get-Module ImportExcel -ListAvailable -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"Carbon\`"               ([bool](Get-Module Carbon -ListAvailable -ErrorAction SilentlyContinue))',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  'Write-Host \`"=== RSAT TOOLS ===\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: AD DS Tools\`"    ((Get-WindowsCapability -Online -Name \`"Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: DNS Tools\`"      ((Get-WindowsCapability -Online -Name \`"Rsat.Dns.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: GP Management\`"  ((Get-WindowsCapability -Online -Name \`"Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: Hyper-V Tools\`"  ((Get-WindowsCapability -Online -Name \`"Rsat.HyperV.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  'Write-Host \`"=== WINDOWS FEATURES ===\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Show \`"Hyper-V\`"              ((Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -EA SilentlyContinue).State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WSL2\`"                 ((Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -EA SilentlyContinue).State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  'Write-Host \`"=== WMI HEALTH ===\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Show \`"WMI Service Running\`"  ((Get-Service Winmgmt -EA SilentlyContinue).Status -eq \`"Running\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WMI Repository OK\`"    ((winmgmt /verifyrepository 2>`$null) -match \`"consistent\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: OS query\`"        ([bool](Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  'Write-Host \`"[OK] = installed/working    [--] = missing or not detected\`" -ForegroundColor Gray'`" ^"
    cmd.exe /c "`"); Set-Content -Path '$f' -Value ($lines -join \`"`n\`") -Encoding UTF8`""
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
