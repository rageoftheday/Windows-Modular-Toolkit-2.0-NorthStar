@echo off
title Powershell Uptime
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
