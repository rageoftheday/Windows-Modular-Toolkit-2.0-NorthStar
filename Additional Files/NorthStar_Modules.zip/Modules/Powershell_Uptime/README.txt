Powershell Uptime

Rebuilt from original label :ps_uptime.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
