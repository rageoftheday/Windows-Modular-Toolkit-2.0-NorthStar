# ============================================================
# POWERSHELL UPTIME
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL UPTIME" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $OS = Get-CimInstance Win32_OperatingSystem
    $Boot = $OS.LastBootUpTime
    $Uptime = (Get-Date) - $Boot

    Write-Host "--- SYSTEM UPTIME ---" -ForegroundColor Cyan
    Write-Host "Last boot : $Boot"
    Write-Host "Uptime    : $($Uptime.Days) days, $($Uptime.Hours) hours, $($Uptime.Minutes) minutes"
    Write-Host ""
}
