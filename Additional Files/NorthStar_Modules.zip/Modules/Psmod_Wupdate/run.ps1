# ============================================================
# PSMOD WUPDATE
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PSMOD WUPDATE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Install-Module -Name PSWindowsUpdate -Force -AllowClobber

}
