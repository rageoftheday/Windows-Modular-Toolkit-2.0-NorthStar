Psmod Wupdate

Rebuilt from original label :psmod_wupdate.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
