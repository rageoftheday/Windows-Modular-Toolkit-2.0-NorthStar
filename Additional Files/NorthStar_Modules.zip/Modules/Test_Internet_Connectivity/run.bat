@echo off
title Test Internet Connectivity
color 0B
cls
echo ============================================================
echo Test Internet Connectivity
echo ============================================================
echo.
echo Tests internet access and DNS resolution.
echo.
echo Demo module executed successfully.
echo.
pause
