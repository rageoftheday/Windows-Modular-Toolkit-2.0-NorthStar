Deep Cleanup

Rebuilt from original label :allcleanup.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
