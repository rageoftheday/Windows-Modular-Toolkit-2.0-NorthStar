
@echo off
title Deep Cleanup
color 0C
cls

echo ============================================================
echo                     DEEP CLEANUP
echo ============================================================
echo.

echo [1/6] Clearing temporary files...
del /f /s /q "%temp%\*" >nul 2>&1
del /f /s /q "C:\Windows\Temp\*" >nul 2>&1

echo [2/6] Clearing thumbnail cache...
taskkill /f /im explorer.exe >nul 2>&1
del /f /s /q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*" >nul 2>&1
start explorer.exe

echo [3/6] Clearing Windows Update cache...
net stop wuauserv >nul 2>&1
net stop bits >nul 2>&1
rd /s /q "C:\Windows\SoftwareDistribution" >nul 2>&1
net start wuauserv >nul 2>&1
net start bits >nul 2>&1

echo [4/6] Flushing DNS cache...
ipconfig /flushdns >nul

echo [5/6] Emptying Recycle Bin...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"Clear-RecycleBin -Force -ErrorAction SilentlyContinue"

echo [6/6] Running component cleanup...
Dism /Online /Cleanup-Image /StartComponentCleanup

echo.
echo ============================================================
echo Deep Cleanup Completed
echo ============================================================
echo.
echo Advanced maintenance tasks completed.
echo.
pause
