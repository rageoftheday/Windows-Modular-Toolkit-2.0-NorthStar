# ============================================================
# DEEP CLEANUP
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DEEP CLEANUP" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Running all cleanup steps...'
    Write-Host '  This runs all 8 cleanup options in sequence.'
    Write-Host '  Explorer will restart briefly during thumbnail cleanup.'
    Write-Host ""
    Write-Host '[1/8] Clearing user TEMP...'
    cmd.exe /c "del /q /f /s `"$env:TEMP\*`" >nul 2>&1"
    Write-Host '[2/8] Clearing Windows Temp...'
    cmd.exe /c "del /q /f /s `"C:\Windows\Temp\*`" >nul 2>&1"
    Write-Host '[3/8] Clearing Prefetch...'
    cmd.exe /c "del /q /f `"C:\Windows\Prefetch\*`" >nul 2>&1"
    Write-Host '[4/8] Clearing Windows Update Cache...'
    cmd.exe /c "net stop wuauserv >nul 2>&1"
    cmd.exe /c "net stop bits >nul 2>&1"
    cmd.exe /c "rd /s /q `"C:\Windows\SoftwareDistribution\Download`" >nul 2>&1"
    cmd.exe /c "net start wuauserv >nul 2>&1"
    cmd.exe /c "net start bits >nul 2>&1"
    Write-Host '[5/8] Clearing Delivery Optimization Cache...'
    cmd.exe /c "del /q /f /s `"C:\Windows\SoftwareDistribution\DeliveryOptimization\*`" >nul 2>&1"
    Write-Host '[6/8] Clearing Recent Items...'
    cmd.exe /c "del /q /f `"$AppData\Microsoft\Windows\Recent\*`" >nul 2>&1"
    Write-Host '[7/8] Clearing Thumbnail Cache...'
    cmd.exe /c "taskkill /im explorer.exe /f >nul 2>&1"
    cmd.exe /c "del /q /f `"$env:USERPROFILE\AppData\Local\Microsoft\Windows\Explorer\thumbcache*`" >nul 2>&1"
    cmd.exe /c "start `"`" /B explorer.exe"
    Write-Host '[8/8] Clearing Browser Caches...'
    cmd.exe /c "del /q /f /s `"$LocalAppData\Microsoft\Edge\User Data\Default\Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Microsoft\Edge\User Data\Default\Code Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Google\Chrome\User Data\Default\Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Google\Chrome\User Data\Default\Code Cache\*`" >nul 2>&1"
    Write-Host ""
    Write-Host 'All cleanup complete.'
    Write-Host ""

}
