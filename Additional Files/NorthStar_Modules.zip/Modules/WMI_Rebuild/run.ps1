# ============================================================
# WMI REBUILD
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WMI REBUILD" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Rebuilding WMI Repository...'
    Write-Host '  This stops the WMI service, salvages what it can from'
    Write-Host '  the existing database, rebuilds it from scratch, then'
    Write-Host '  restarts the service. Safe to run on any machine.'
    Write-Host ""
    $confirm = Read-Host 'Proceed? (Y/N):'
    Write-Host ""
    Write-Host 'Stopping WMI service...'
    cmd.exe /c "net stop winmgmt /y >nul 2>&1"
    Write-Host 'Salvaging repository...'
    cmd.exe /c "winmgmt /salvagerepository"
    Write-Host 'Resetting repository...'
    cmd.exe /c "winmgmt /resetrepository"
    Write-Host 'Restarting WMI service...'
    cmd.exe /c "net start winmgmt >nul 2>&1"
    Write-Host ""
    Write-Host 'Verifying after rebuild...'
    cmd.exe /c "winmgmt /verifyrepository"
Write-Host ""
Write-Host "Full WMI repair sequence complete." -ForegroundColor Green

Write-Host ""
Pause-Toolkit
}
