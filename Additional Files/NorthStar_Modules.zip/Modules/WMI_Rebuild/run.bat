@echo off
title WMI Rebuild
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
