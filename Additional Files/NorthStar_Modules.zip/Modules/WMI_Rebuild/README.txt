WMI Rebuild

Rebuilt from original label :wmi_rebuild.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
