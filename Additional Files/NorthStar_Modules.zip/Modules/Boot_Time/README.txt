Boot Time

Rebuilt from original label :boot_time.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
