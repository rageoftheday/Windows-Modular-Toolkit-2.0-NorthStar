@echo off
title Boot Time
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
