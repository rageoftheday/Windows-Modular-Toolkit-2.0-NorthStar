# ============================================================
# BOOT TIME
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "BOOT TIME" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Last Boot Time and Uptime:'
    Write-Host '  Shows when the machine was last started and how long'
    Write-Host '  it has been running. Machines with very long uptimes'
    Write-Host '  may need a reboot to apply updates or clear issues.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'boottime.ps1'
    Set-Content -Path $f -Value '$boot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime' -Encoding UTF8
    Add-Content -Path $f -Value '$up = (Get-Date) - $boot' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host (''Last Boot : '' + $boot) -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host (''Uptime    : '' + $up.Days + ''d '' + $up.Hours + ''h '' + $up.Minutes + ''m'') -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'if ($up.Days -gt 14) { Write-Host ''TIP: This machine has been running for over 2 weeks. Consider rebooting.'' -ForegroundColor Yellow }' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
