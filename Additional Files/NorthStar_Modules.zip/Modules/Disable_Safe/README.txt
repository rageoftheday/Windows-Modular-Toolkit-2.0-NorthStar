Disable Safe

Rebuilt from original label :disable_safe.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
