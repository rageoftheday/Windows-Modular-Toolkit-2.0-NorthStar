@echo off
title Disable Safe
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
