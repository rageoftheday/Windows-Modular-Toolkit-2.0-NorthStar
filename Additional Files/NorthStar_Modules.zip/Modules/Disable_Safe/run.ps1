# ============================================================
# DISABLE SAFE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DISABLE SAFE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    cmd.exe /c "bcdedit /deletevalue {current} safeboot"
    cmd.exe /c "if errorlevel 1 ("
    Write-Host 'ERROR: Run as Administrator or already disabled.'
    cmd.exe /c ") else ("
    Write-Host 'Safe Mode DISABLED. Normal boot restored.'
    cmd.exe /c ")"
    Write-Host ""

}
