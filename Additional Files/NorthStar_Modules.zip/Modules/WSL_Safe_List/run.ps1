# ============================================================
# WSL SAFE LIST
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WSL SAFE LIST" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host '------------------------------------------------------------'
    Write-Host 'INSTALLED DISTROS (SAFE MODE)'
    Write-Host '------------------------------------------------------------'
    Write-Host ""
    cmd.exe /c "reg query `"HKCU\Software\Microsoft\Windows\CurrentVersion\Lxss`" >nul 2>&1"
    cmd.exe /c "if errorlevel 1 ("
    Write-Host 'No WSL distros found or WSL not initialized.'
    cmd.exe /c ") else ("
    Write-Host 'WSL registry exists (distros likely installed)'
    cmd.exe /c ")"
    Write-Host ""
    Write-Host ""

}
