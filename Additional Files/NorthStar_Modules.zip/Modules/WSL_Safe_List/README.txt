WSL Safe List

Rebuilt from original label :wsl_safe_list.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
