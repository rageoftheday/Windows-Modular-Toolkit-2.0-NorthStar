@echo off
title WSL Safe List
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
