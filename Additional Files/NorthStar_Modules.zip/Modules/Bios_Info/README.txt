Bios Info

Rebuilt from original label :bios_info.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
