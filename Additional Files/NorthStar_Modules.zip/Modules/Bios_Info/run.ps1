# ============================================================
# BIOS INFO
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "BIOS INFO" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Motherboard and BIOS Information:'
    Write-Host '  Shows motherboard model, manufacturer, and BIOS version.'
    Write-Host '  Useful for checking if a BIOS update is available or'
    Write-Host '  confirming hardware when ordering parts.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'biosinfo.ps1'
    Set-Content -Path $f -Value 'Write-Host ''--- BIOS ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_BIOS | Select-Object Manufacturer,Name,Version,ReleaseDate | Format-List' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- Motherboard ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product,SerialNumber,Version | Format-List' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
