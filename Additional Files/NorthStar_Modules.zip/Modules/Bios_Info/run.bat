@echo off
title Bios Info
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
