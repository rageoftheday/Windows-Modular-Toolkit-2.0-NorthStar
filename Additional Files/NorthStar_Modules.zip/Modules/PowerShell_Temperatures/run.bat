@echo off
title PowerShell Temperatures
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
