PowerShell Temperatures

Rebuilt from original label :ps_temps.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
