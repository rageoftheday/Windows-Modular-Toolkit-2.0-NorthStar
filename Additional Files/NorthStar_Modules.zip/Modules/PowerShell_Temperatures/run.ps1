# ============================================================
# POWERSHELL TEMPERATURES
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL TEMPERATURES" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "SilentlyContinue"

    Write-Host "--- CPU UTILIZATION (PER CORE) ---" -ForegroundColor Cyan

    Get-Counter "\Processor(*)\% Processor Time" |
        Select-Object -ExpandProperty CounterSamples |
        Where-Object { $_.InstanceName -ne "_total" } |
        Select-Object `
            InstanceName,
            @{N="Usage%";E={[math]::Round($_.CookedValue,1)}} |
        Format-Table -AutoSize

    Write-Host ""
    Write-Host "--- SOURCE 1: ACPI THERMAL ZONES ---" -ForegroundColor Cyan

    $acpi = Get-CimInstance `
        -Namespace root/wmi `
        -ClassName MSAcpi_ThermalZoneTemperature

    if ($acpi) {
        $acpi |
            Select-Object `
                InstanceName,
                @{N="TempC";E={[math]::Round(($_.CurrentTemperature / 10) - 273.15, 1)}} |
            Format-Table -AutoSize
    }
    else {
        Write-Host "ACPI Thermal data not available." -ForegroundColor Gray
    }

    Write-Host ""
    Write-Host "--- SOURCE 2: PERFORMANCE COUNTERS ---" -ForegroundColor Cyan

    $perf = Get-CimInstance `
        -ClassName Win32_PerfFormattedData_Counters_ThermalZoneInformation

    if ($perf) {
        $perf |
            Select-Object `
                Name,
                @{N="TempC";E={[math]::Round(($_.HighPrecisionTemperature / 10) - 273.15, 1)}} |
            Format-Table -AutoSize
    }
    else {
        Write-Host "Performance Counter thermal data not available." -ForegroundColor Gray
    }

    Write-Host ""
}
