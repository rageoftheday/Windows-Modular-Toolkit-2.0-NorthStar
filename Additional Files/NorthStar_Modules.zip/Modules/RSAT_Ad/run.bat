@echo off
title RSAT Ad
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
