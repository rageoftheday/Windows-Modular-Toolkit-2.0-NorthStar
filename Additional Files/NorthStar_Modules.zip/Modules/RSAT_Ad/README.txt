RSAT Ad

Rebuilt from original label :rsat_ad.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
