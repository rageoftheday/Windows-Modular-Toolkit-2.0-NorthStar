Clear Recent

Rebuilt from original label :clear_recent.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
