@echo off
title Clear Recent
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
