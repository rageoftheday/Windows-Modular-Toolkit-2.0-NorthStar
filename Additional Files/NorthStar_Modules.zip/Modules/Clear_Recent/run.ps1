# ============================================================
# CLEAR RECENT
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CLEAR RECENT" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Clearing Recent Items list...'
    Write-Host '  Removes shortcuts in the Recent Items folder that'
    Write-Host '  appear in the Start menu and File Explorer jump lists.'
    cmd.exe /c "del /q /f `"$AppData\Microsoft\Windows\Recent\*`" >nul 2>&1"
    Write-Host 'Done.'
    Write-Host ""

}
