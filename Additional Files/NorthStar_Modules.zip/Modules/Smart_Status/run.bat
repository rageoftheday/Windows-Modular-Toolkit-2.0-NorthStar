@echo off
title Smart Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
