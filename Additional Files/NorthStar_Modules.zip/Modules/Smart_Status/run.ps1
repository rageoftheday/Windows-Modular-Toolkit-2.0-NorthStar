# ============================================================
# SMART STATUS
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SMART STATUS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "SMART STATUS"

    Write-Host "Displays basic disk SMART health status."
    Write-Host ""

    Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue |
        Select-Object InstanceName, PredictFailure, Reason |
        Format-Table -AutoSize

    Write-Host ""
    Write-Host "Physical disks:"
    Get-PhysicalDisk -ErrorAction SilentlyContinue |
        Select-Object FriendlyName, MediaType, HealthStatus, OperationalStatus, Size |
        Format-Table -AutoSize

    Write-Host ""
    Pause-Toolkit
}
