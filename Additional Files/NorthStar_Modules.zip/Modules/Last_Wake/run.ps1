# ============================================================
# LAST WAKE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "LAST WAKE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Last Wake Source and Active Wake Timers:'
    Write-Host '  Shows what last woke the computer from sleep, and lists'
    Write-Host '  any active scheduled tasks or processes that are allowed'
    Write-Host '  to wake the machine. Useful if a PC keeps waking up.'
    Write-Host ""
    Write-Host '--- LAST WAKE SOURCE ---'
    cmd.exe /c "powercfg /lastwake"
    Write-Host ""
    Write-Host '--- ACTIVE WAKE TIMERS ---'
    cmd.exe /c "powercfg /waketimers"
    Write-Host ""
    Write-Host ""

}
