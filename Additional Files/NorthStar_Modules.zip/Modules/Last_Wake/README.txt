Last Wake

Rebuilt from original label :last_wake.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
