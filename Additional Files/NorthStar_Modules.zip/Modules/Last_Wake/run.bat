@echo off
title Last Wake
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
