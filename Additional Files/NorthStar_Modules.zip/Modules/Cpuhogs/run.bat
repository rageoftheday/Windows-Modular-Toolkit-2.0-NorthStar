@echo off
title Cpuhogs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
