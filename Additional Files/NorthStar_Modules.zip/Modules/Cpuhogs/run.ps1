# ============================================================
# CPUHOGS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CPUHOGS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Top CPU Processes - 1 Second Snapshot:'
    Write-Host '  Captures CPU activity over 1 second and shows the top'
    Write-Host '  15 processes using the most CPU. Useful for finding'
    Write-Host '  what is making a machine run hot or slow.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'cpuhogs.ps1'
    Set-Content -Path $f -Value '$s1 = Get-Process | Select-Object Id,ProcessName,CPU,WorkingSet' -Encoding UTF8
    Add-Content -Path $f -Value 'Start-Sleep -Milliseconds 1000' -Encoding UTF8
    Add-Content -Path $f -Value '$s2 = Get-Process | Select-Object Id,ProcessName,CPU,WorkingSet' -Encoding UTF8
    Add-Content -Path $f -Value '$r = foreach ($p in $s2) {' -Encoding UTF8
    Add-Content -Path $f -Value '$prev = $s1 | Where-Object { $_.Id -eq $p.Id }' -Encoding UTF8
    Add-Content -Path $f -Value 'if ($prev -and $p.CPU -ne $null -and $prev.CPU -ne $null) {' -Encoding UTF8
    Add-Content -Path $f -Value '[PSCustomObject]@{Name=$p.ProcessName;PID=$p.Id;CPU_Delta=[math]::Round($p.CPU-$prev.CPU,2);MemMB=[math]::Round($p.WorkingSet/1MB,1)}' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    Add-Content -Path $f -Value '$r | Sort-Object CPU_Delta -Descending | Select-Object -First 15 | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
