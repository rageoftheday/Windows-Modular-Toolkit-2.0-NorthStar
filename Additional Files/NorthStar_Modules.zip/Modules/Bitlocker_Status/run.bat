@echo off
title Bitlocker Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
