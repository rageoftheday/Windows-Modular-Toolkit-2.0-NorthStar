# ============================================================
# BITLOCKER STATUS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "BITLOCKER STATUS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'BitLocker Encryption Status - All Drives:'
    Write-Host '  Shows whether each drive is encrypted with BitLocker,'
    Write-Host '  the encryption method used, and protection status.'
    Write-Host '  A drive showing Protection OFF may need attention.'
    Write-Host ""
    cmd.exe /c "manage-bde -status"
    Write-Host ""
    Write-Host ""

}
