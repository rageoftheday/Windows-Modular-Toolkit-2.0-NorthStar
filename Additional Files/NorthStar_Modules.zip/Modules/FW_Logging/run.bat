@echo off
title FW Logging
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
