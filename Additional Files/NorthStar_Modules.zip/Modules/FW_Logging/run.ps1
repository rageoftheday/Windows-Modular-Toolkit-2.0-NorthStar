# ============================================================
# FW LOGGING
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FW LOGGING" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Firewall Logging - Enable or Disable:'
    Write-Host '  Windows Firewall can log dropped packets and successful'
    Write-Host '  connections to:'
    Write-Host '  C:\Windows\System32\LogFiles\Firewall\'
    Write-Host '  Useful for diagnosing blocked traffic.'
    Write-Host ""
    Write-Host '  1. Enable logging (dropped + allowed)'
    Write-Host '  2. Disable logging'
    Write-Host '  3. Back'
    Write-Host ""
    $fwlog = Read-Host 'Select:'
    cmd.exe /c "if `"$fwlog`"==`"1`" ("
    Write-Host ""
    Write-Host 'Enabling firewall logging...'
    cmd.exe /c "netsh advfirewall set allprofiles logging droppedconnections enable"
    cmd.exe /c "netsh advfirewall set allprofiles logging allowedconnections enable"
    Write-Host 'Logging enabled.'
    Write-Host ""
    cmd.exe /c ")"
    cmd.exe /c "if `"$fwlog`"==`"2`" ("
    Write-Host ""
    Write-Host 'Disabling firewall logging...'
    cmd.exe /c "netsh advfirewall set allprofiles logging droppedconnections disable"
    cmd.exe /c "netsh advfirewall set allprofiles logging allowedconnections disable"
    Write-Host 'Logging disabled.'
    Write-Host ""
    cmd.exe /c ")"
    Write-Host ""

}
