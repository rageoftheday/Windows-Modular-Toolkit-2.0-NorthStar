FW Logging

Rebuilt from original label :fw_logging.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
