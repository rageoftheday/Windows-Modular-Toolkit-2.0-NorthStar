Powershell Dupes

Rebuilt from original label :ps_dupes.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
