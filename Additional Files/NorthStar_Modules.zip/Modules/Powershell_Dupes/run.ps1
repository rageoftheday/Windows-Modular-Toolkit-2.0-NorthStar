# ============================================================
# POWERSHELL DUPES
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL DUPES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $Path = Read-Host "Enter folder path to scan for duplicate file names"

    if ([string]::IsNullOrWhiteSpace($Path) -or !(Test-Path $Path)) {
        Write-Host "Invalid path." -ForegroundColor Red
        return
    }

    Get-ChildItem $Path -Recurse -File -ErrorAction SilentlyContinue |
        Group-Object Name |
        Where-Object { $_.Count -gt 1 } |
        ForEach-Object {
            Write-Host ""
            Write-Host "Duplicate name: $($_.Name)" -ForegroundColor Yellow
            $_.Group | Select-Object FullName, Length, LastWriteTime | Format-Table -AutoSize
        }
}
