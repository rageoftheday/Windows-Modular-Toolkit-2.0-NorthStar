@echo off
title Powershell Dupes
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
