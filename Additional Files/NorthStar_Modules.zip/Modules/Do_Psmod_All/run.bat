@echo off
title Do Psmod All
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
