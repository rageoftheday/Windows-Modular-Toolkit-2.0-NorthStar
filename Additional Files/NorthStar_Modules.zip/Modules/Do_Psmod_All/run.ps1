# ============================================================
# DO PSMOD ALL
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DO PSMOD ALL" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"

    $Modules = @(
        "PSWindowsUpdate",
        "ImportExcel",
        "Carbon"
    )

    Write-Host "Ensuring NuGet provider..." -ForegroundColor Cyan

    if (-not (Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue)) {
        Install-PackageProvider -Name NuGet -Force -Scope AllUsers | Out-Null
    }

    Set-PSRepository `
        -Name PSGallery `
        -InstallationPolicy Trusted `
        -ErrorAction SilentlyContinue

    $Total = $Modules.Count
    $Index = 0

    foreach ($Module in $Modules) {

        $Index++

        Write-Host "[$Index/$Total] $Module" -ForegroundColor Cyan

        $Installed = Get-Module -ListAvailable -Name $Module

        if ($Installed) {
            Write-Host "  [SKIP] Already installed" -ForegroundColor Yellow
            continue
        }

        try {
            Install-Module `
                -Name $Module `
                -Force `
                -AllowClobber `
                -Scope AllUsers `
                -ErrorAction Stop

            if (Get-Module -ListAvailable -Name $Module) {
                Write-Host "  [OK] Installed successfully" -ForegroundColor Green
            }
            else {
                Write-Host "  [!!] Installed but not detected" -ForegroundColor Yellow
            }
        }
        catch {
            Write-Host "  [FAIL] $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    Write-Host ""
    Write-Host "Module installs complete." -ForegroundColor Green
    Write-Host ""
}