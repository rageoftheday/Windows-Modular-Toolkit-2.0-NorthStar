Do Psmod All

Rebuilt from original label :do_psmod_all.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
