# ============================================================
# CERT EXPIRY
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CERT EXPIRY" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "CERT EXPIRY"

    Write-Host "Scans the local machine certificate store."
    Write-Host "Shows expired certificates and certificates expiring within 90 days."
    Write-Host ""

    $Now = Get-Date
    $Warn = $Now.AddDays(90)

    $Certs = Get-ChildItem Cert:\LocalMachine -Recurse -ErrorAction SilentlyContinue |
        Where-Object {
            $_ -is [System.Security.Cryptography.X509Certificates.X509Certificate2]
        }

    $Expired = $Certs |
        Where-Object {
            $_.NotAfter -lt $Now
        }

    $Expiring = $Certs |
        Where-Object {
            $_.NotAfter -ge $Now -and $_.NotAfter -lt $Warn
        }

    Write-Host "Expired Certificates" -ForegroundColor Red
    Write-Host ""

    if ($Expired) {
        $Expired |
            Select-Object Subject, Issuer, NotAfter, Thumbprint |
            Format-Table -AutoSize
    }
    else {
        Write-Host "None found." -ForegroundColor Green
    }

    Write-Host ""
    Write-Host "Expiring Within 90 Days" -ForegroundColor Yellow
    Write-Host ""

    if ($Expiring) {
        $Expiring |
            Select-Object Subject, Issuer, NotAfter, Thumbprint |
            Format-Table -AutoSize
    }
    else {
        Write-Host "None found." -ForegroundColor Green
    }
}