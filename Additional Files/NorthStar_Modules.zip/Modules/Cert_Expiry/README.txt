Cert Expiry

Rebuilt from original label :cert_expiry.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
