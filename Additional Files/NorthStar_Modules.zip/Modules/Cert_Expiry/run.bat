@echo off
title Cert Expiry
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
