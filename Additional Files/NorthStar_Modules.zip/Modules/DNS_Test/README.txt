DNS Test

Rebuilt from original label :dns_test.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
