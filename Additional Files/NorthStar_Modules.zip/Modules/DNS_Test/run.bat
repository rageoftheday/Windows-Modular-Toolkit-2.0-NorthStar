@echo off
title DNS Test
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
