# ============================================================
# DNS TEST
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DNS TEST" `
    -RequiresAdmin $false `
    -ScriptBlock {


    Show-ToolkitHeader "DNS TEST"
    nslookup microsoft.com

}
