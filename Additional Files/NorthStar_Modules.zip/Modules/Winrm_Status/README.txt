Winrm Status

Rebuilt from original label :winrm_status.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
