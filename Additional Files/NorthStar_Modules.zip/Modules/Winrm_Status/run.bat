@echo off
title Winrm Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
