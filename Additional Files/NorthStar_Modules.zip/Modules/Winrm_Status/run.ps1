# ============================================================
# WINRM STATUS
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WINRM STATUS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "WINRM STATUS"

    Write-Host "Displays Windows Remote Management status."
    Write-Host ""

    $Service = Get-Service WinRM -ErrorAction SilentlyContinue

    if ($Service) {
        $Service | Select-Object Name, Status, StartType | Format-Table -AutoSize
    }
    else {
        Write-Host "WinRM service not found." -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "WinRM listeners:"
    winrm enumerate winrm/config/listener

    Write-Host ""
    Pause-Toolkit
}
