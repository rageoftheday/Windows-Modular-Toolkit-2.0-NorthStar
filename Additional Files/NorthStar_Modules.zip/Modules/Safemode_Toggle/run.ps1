# ============================================================
# SAFEMODE TOGGLE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SAFEMODE TOGGLE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    cmd.exe /c "setlocal EnableDelayedExpansion"
    Write-Host '------------------------------------------------------------'
    Write-Host '               SAFE MODE TOGGLE'
    Write-Host '------------------------------------------------------------'
    Write-Host ""
    Write-Host 'Safe Mode starts Windows with only essential drivers'
    Write-Host 'and services. Use it for troubleshooting.'
    Write-Host ""
    Write-Host 'WARNING: Misconfiguration may require recovery tools.'
    Write-Host ""
    Write-Host '1. Enable Safe Mode (next reboot)'
    Write-Host '2. Disable Safe Mode (normal boot)'
    Write-Host '3. Back'
    Write-Host ""
    $sm = Read-Host 'Select:'
    cmd.exe /c "if `"$sm`"==`"1`" goto enable_safe"
    cmd.exe /c "if `"$sm`"==`"2`" goto disable_safe"
    Write-Host ""

}
