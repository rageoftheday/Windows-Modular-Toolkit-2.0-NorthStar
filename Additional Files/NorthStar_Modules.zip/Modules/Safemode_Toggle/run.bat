@echo off
title Safemode Toggle
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
