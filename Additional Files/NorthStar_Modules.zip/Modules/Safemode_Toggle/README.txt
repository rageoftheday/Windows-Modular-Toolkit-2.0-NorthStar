Safemode Toggle

Rebuilt from original label :safemode_toggle.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
