Defrag Anal

Rebuilt from original label :defrag_anal.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
