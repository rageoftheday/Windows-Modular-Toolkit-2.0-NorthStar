@echo off
title Defrag Anal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
