# ============================================================
# DEFRAG ANAL
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DEFRAG ANAL" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Defragmentation Analysis - C: Drive:'
    Write-Host '  Analyses C: fragmentation level without performing any'
    Write-Host '  defragmentation. For SSDs this is informational only -'
    Write-Host '  do not defrag SSDs as it reduces their lifespan.'
    Write-Host ""
    cmd.exe /c "defrag C: /A /V"
    Write-Host ""
    Write-Host ""

}
