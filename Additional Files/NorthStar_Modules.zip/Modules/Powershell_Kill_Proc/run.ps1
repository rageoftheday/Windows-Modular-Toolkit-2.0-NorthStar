# ============================================================
# POWERSHELL KILL PROC
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL KILL PROC" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $Name = Read-Host "Enter process name to stop"

    if ([string]::IsNullOrWhiteSpace($Name)) {
        return
    }

    $Processes = Get-Process -Name $Name -ErrorAction SilentlyContinue

    if (!$Processes) {
        Write-Host "No matching process found." -ForegroundColor Yellow
        return
    }

    $Processes | Select-Object Id, ProcessName, CPU, WorkingSet | Format-Table -AutoSize

    $Confirm = Read-Host "Stop these processes? (Y/N)"

    if ($Confirm.ToUpper() -eq "Y") {
        $Processes | Stop-Process -Force
        Write-Host "Processes stopped." -ForegroundColor Green
    }
}
