@echo off
title Powershell Kill Proc
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
