Powershell Kill Proc

Rebuilt from original label :ps_kill_proc.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
