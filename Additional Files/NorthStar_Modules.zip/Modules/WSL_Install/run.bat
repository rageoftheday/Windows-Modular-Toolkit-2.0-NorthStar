@echo off
title WSL Install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
