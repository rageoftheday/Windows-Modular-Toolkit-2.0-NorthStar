WSL Install

Rebuilt from original label :wsl_install.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
