# ============================================================
# WSL INSTALL
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WSL INSTALL" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Installing WSL...'
    cmd.exe /c "powershell -NoProfile -ExecutionPolicy Bypass -Command `"Start-Process wsl.exe -ArgumentList '--install' -Wait`""
    Write-Host ""

}
