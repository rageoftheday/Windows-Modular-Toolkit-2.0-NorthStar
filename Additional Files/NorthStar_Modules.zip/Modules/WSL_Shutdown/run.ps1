# ============================================================
# WSL SHUTDOWN
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WSL SHUTDOWN" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    cmd.exe /c "wsl --shutdown 2>nul"
    Write-Host 'Done.'
    Write-Host ""

}
