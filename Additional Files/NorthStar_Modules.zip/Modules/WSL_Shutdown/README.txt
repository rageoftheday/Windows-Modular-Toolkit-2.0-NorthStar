WSL Shutdown

Rebuilt from original label :wsl_shutdown.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
