@echo off
title WSL Shutdown
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
