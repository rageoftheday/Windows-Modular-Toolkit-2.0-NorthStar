Powershell Sessions

Rebuilt from original label :ps_sessions.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
