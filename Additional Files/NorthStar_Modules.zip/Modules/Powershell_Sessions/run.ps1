# ============================================================
# POWERSHELL SESSIONS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL SESSIONS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Active User Sessions:'
    Write-Host '  Shows who is currently logged in and via what method'
    Write-Host '  (console, remote desktop, etc).'
    Write-Host ""
    cmd.exe /c "query user 2>nul"
    Write-Host ""
    $f = Join-Path $env:TEMP 'sessions.ps1'
    Set-Content -Path $f -Value 'Get-CimInstance Win32_LogonSession | Select-Object LogonType,StartTime | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
