@echo off
title Powershell Sessions
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
