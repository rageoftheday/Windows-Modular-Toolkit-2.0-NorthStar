@echo off
title Powershell TCP Procs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
