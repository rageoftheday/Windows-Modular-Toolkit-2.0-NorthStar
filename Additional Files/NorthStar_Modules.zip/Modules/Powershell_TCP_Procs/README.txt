Powershell TCP Procs

Rebuilt from original label :ps_tcp_procs.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
