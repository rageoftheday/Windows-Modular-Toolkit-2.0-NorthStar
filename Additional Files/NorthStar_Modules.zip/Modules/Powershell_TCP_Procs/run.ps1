# ============================================================
# POWERSHELL TCP PROCS
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL TCP PROCS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "TCP PROCESSES"

    Write-Host "Shows TCP connections mapped to owning processes."
    Write-Host ""

    Get-NetTCPConnection -ErrorAction SilentlyContinue |
        Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess,
            @{Name="ProcessName";Expression={
                try {
                    (Get-Process -Id $_.OwningProcess -ErrorAction Stop).ProcessName
                }
                catch {
                    ""
                }
            }} |
        Sort-Object LocalPort |
        Format-Table -AutoSize

    Write-Host ""
    Pause-Toolkit
}
