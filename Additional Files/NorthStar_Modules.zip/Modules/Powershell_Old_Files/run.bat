@echo off
title Powershell Old Files
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
