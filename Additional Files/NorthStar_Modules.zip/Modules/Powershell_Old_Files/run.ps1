# ============================================================
# POWERSHELL OLD FILES
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL OLD FILES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $Path = Read-Host "Enter folder path"
    $Days = Read-Host "Find files older than how many days? (default: 90)"

    if ([string]::IsNullOrWhiteSpace($Days)) {
        $Days = 90
    }

    if ([string]::IsNullOrWhiteSpace($Path) -or !(Test-Path $Path)) {
        Write-Host "Invalid path." -ForegroundColor Red
        return
    }

    $Cutoff = (Get-Date).AddDays(-[int]$Days)

    Get-ChildItem $Path -Recurse -File -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $Cutoff } |
        Select-Object FullName, LastWriteTime, @{N="SizeMB";E={[math]::Round($_.Length/1MB,2)}} |
        Format-Table -AutoSize
}
