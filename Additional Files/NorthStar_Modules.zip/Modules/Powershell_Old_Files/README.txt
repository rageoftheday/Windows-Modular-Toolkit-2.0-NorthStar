Powershell Old Files

Rebuilt from original label :ps_old_files.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
