@echo off
title RSAT Hyperv
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
