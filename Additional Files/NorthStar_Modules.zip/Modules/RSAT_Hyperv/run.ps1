# ============================================================
# RSAT HYPERV
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "RSAT HYPERV" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $Cap = "Rsat.HyperV.Tools~~~~0.0.1.0"

    Write-Host "Installing RSAT: Hyper-V Tools..."
    Write-Host "Lets you manage Hyper-V virtual machines remotely."
    Write-Host ""

    $State = (
        Get-WindowsCapability `
            -Online `
            -Name $Cap `
            -ErrorAction SilentlyContinue
    ).State

    if ($State -eq "Installed") {
        Write-Host "Already installed." -ForegroundColor Green
        return
    }

    Write-Host "Installing..." -ForegroundColor Cyan

    try {
        Add-WindowsCapability `
            -Online `
            -Name $Cap `
            -ErrorAction Stop | Out-Null

        Write-Host "Done." -ForegroundColor Green
    }
    catch {
        Write-Host "Failed: $($_.Exception.Message)" -ForegroundColor Red
    }

    Write-Host ""
}