RSAT Hyperv

Rebuilt from original label :rsat_hyperv.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
