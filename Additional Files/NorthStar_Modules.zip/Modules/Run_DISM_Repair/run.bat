@echo off
title Run DISM Repair
color 0B
cls
echo ============================================================
echo Run DISM Repair
echo ============================================================
echo.
echo Repairs Windows component corruption.
echo.
echo Demo module executed successfully.
echo.
pause
