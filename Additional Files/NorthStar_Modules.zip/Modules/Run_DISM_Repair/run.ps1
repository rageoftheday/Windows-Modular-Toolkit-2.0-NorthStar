# ============================================================
# RUN DISM REPAIR
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "RUN DISM REPAIR" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Running DISM RestoreHealth...'
    Write-Host '  Downloads fresh Windows component files from Microsoft'
    Write-Host '  and repairs the Windows image that SFC uses to fix files.'
    Write-Host '  Requires internet. Run this before SFC if you suspect'
    Write-Host '  system file corruption. This may take 10-20 minutes.'
    Write-Host ""
    Write-Host 'Repair: DISM RestoreHealth started at %time% >> "%LOGFILE%" 2>nul'
    cmd.exe /c "dism /online /cleanup-image /restorehealth"
    Write-Host 'Repair: DISM RestoreHealth completed at %time% >> "%LOGFILE%" 2>nul'
    Write-Host ""
    Write-Host 'Done. Now run the appropriate validator module (SFC) to apply the repairs.'
    Write-Host ""

}
