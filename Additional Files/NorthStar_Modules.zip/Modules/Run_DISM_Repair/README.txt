Run DISM Repair

Rebuilt from original label :dism.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
