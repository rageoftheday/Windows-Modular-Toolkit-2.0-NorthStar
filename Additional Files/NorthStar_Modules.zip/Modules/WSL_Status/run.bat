@echo off
title WSL Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
