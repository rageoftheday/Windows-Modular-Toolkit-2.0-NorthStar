# ============================================================
# WSL STATUS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WSL STATUS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host '------------------------------------------------------------'
    Write-Host '             WSL (WINDOWS SUBSYSTEM FOR LINUX)'
    Write-Host '------------------------------------------------------------'
    Write-Host ""
    Write-Host 'Checking WSL safely (no execution triggers)'
    Write-Host ""
    cmd.exe /c "if exist `"$windir\System32\wsl.exe`" ("
    Write-Host '[STATUS] WSL binary exists'
    cmd.exe /c ") else ("
    Write-Host '[STATUS] WSL NOT installed'
    cmd.exe /c ")"
    Write-Host ""
    cmd.exe /c "reg query `"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Lxss`" >nul 2>&1"
    cmd.exe /c "if errorlevel 1 ("
    Write-Host '[STATUS] WSL not initialized or no distros'
    cmd.exe /c ") else ("
    Write-Host '[STATUS] WSL registry detected'
    cmd.exe /c ")"
    Write-Host ""
    Write-Host ""

}
