@echo off
title Powershell Threats
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
