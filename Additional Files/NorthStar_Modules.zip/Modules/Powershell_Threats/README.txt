Powershell Threats

Rebuilt from original label :ps_threats.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
