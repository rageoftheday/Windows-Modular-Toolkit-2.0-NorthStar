# ============================================================
# POWERSHELL THREATS
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL THREATS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "DEFENDER THREATS"

    Write-Host "Displays Microsoft Defender threat detections."
    Write-Host ""

    if (Get-Command Get-MpThreat -ErrorAction SilentlyContinue) {
        Get-MpThreat | Format-Table -AutoSize
    }
    else {
        Write-Host "Microsoft Defender PowerShell cmdlets are not available." -ForegroundColor Yellow
    }

    Write-Host ""
    Pause-Toolkit
}
