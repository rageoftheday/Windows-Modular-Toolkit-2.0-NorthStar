@echo off
title Failed Logons
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
