# ============================================================
# FAILED LOGONS
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FAILED LOGONS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "FAILED LOGONS"

    Write-Host "Displays recent failed logon events from the Security log."
    Write-Host ""

    $Events = Get-WinEvent -FilterHashtable @{
        LogName = "Security"
        Id      = 4625
    } -MaxEvents 25 -ErrorAction SilentlyContinue

    if (!$Events) {
        Write-Host "No failed logon events found or access was denied." -ForegroundColor Yellow
        return
    }

    $Events |
        Select-Object TimeCreated, Id, ProviderName, Message |
        Format-List

    Write-Host ""
    Pause-Toolkit
}
