Failed Logons

Rebuilt from original label :failed_logons.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
