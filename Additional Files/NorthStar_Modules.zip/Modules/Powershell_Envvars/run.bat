@echo off
title Powershell Envvars
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
