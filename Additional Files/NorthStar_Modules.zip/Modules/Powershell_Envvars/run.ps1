# ============================================================
# POWERSHELL ENVVARS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL ENVVARS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Environment Variables - All:'
    Write-Host '  Shows all environment variables set in the current'
    Write-Host '  session including system PATH, TEMP locations, and'
    Write-Host '  any custom variables set by software or admins.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'envvars.ps1'
    Set-Content -Path $f -Value 'Get-ChildItem Env: | Sort-Object Name | Format-Table Name,Value -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
