Powershell Envvars

Rebuilt from original label :ps_envvars.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
