ARP Table

Rebuilt from original label :arp_table.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
