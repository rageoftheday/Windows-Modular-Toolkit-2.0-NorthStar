@echo off
title ARP Table
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
