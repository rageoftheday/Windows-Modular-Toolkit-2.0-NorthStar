# ============================================================
# ARP TABLE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "ARP TABLE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'ARP Table - All Interfaces:'
    Write-Host '  Shows the local ARP cache mapping IP addresses to MAC'
    Write-Host '  addresses. Useful for confirming a device is on the'
    Write-Host '  network or investigating duplicate IP conflicts.'
    Write-Host ""
    cmd.exe /c "arp -a"
    Write-Host ""
    Write-Host ""

}
