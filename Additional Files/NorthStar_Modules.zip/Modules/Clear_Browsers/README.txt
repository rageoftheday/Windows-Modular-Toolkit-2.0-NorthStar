Clear Browsers

Rebuilt from original label :clear_browsers.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
