# ============================================================
# CLEAR BROWSERS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CLEAR BROWSERS" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Clearing Browser Caches (Edge + Chrome):'
    Write-Host '  Removes cached web pages, images, and scripts stored'
    Write-Host '  by Microsoft Edge and Google Chrome. This can fix pages'
    Write-Host '  that are loading incorrectly or showing stale content.'
    Write-Host '  Browsing history and saved passwords are NOT affected.'
    Write-Host '  Close your browsers before running this for best results.'
    Write-Host ""
    Write-Host 'Clearing Microsoft Edge cache...'
    cmd.exe /c "del /q /f /s `"$LocalAppData\Microsoft\Edge\User Data\Default\Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Microsoft\Edge\User Data\Default\Code Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Microsoft\Edge\User Data\Default\GPUCache\*`" >nul 2>&1"
    Write-Host 'Clearing Google Chrome cache...'
    cmd.exe /c "del /q /f /s `"$LocalAppData\Google\Chrome\User Data\Default\Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Google\Chrome\User Data\Default\Code Cache\*`" >nul 2>&1"
    cmd.exe /c "del /q /f /s `"$LocalAppData\Google\Chrome\User Data\Default\GPUCache\*`" >nul 2>&1"
    Write-Host ""
    Write-Host 'Browser caches cleared.'
    Write-Host 'TIP: For Firefox, use its built-in clear cache option (Ctrl+Shift+Del).'
    Write-Host ""

}
