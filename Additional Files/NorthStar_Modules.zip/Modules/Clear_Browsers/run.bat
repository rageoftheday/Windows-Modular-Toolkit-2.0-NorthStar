@echo off
title Clear Browsers
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
