# ============================================================
# WMI FULL REPAIR
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WMI FULL REPAIR" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Show-ToolkitHeader "WMI FULL REPAIR"

    Write-Host "Runs a full WMI repair sequence:"
    Write-Host "  1. Verify repository"
    Write-Host "  2. Salvage repository"
    Write-Host "  3. Re-register WMI components"
    Write-Host "  4. Restart WMI service"
    Write-Host "  5. Final verification"
    Write-Host ""

    $Confirm = Read-Host "Proceed with full WMI repair? (Y/N)"

    if ($Confirm.ToUpper() -ne "Y") {
        Write-Host ""
        Write-Host "Cancelled."
        return
    }

    Write-Host ""
    Write-Host "[1/5] Verifying WMI repository..." -ForegroundColor Cyan
    winmgmt /verifyrepository

    Write-Host ""
    Write-Host "[2/5] Salvaging WMI repository..." -ForegroundColor Cyan
    winmgmt /salvagerepository

    Write-Host ""
    Write-Host "[3/5] Re-registering WMI components..." -ForegroundColor Cyan

    $WmiPath = Join-Path $env:WINDIR "System32\wbem"

    Get-ChildItem $WmiPath -Filter "*.mof" -ErrorAction SilentlyContinue |
        ForEach-Object {
            mofcomp $_.FullName | Out-Null
        }

    Get-ChildItem $WmiPath -Filter "*.mfl" -ErrorAction SilentlyContinue |
        ForEach-Object {
            mofcomp $_.FullName | Out-Null
        }

    Get-ChildItem $WmiPath -Filter "*.dll" -ErrorAction SilentlyContinue |
        ForEach-Object {
            regsvr32 /s $_.FullName
        }

    Write-Host "Re-registration complete." -ForegroundColor Green

    Write-Host ""
    Write-Host "[4/5] Restarting WMI service..." -ForegroundColor Cyan

    try {
        Restart-Service winmgmt -Force -ErrorAction Stop
        Write-Host "WMI service restarted." -ForegroundColor Green
    }
    catch {
        Write-Host "Could not restart WMI automatically." -ForegroundColor Yellow
        Write-Host "A reboot may be required."
    }

    Write-Host ""
    Write-Host "[5/5] Final verification..." -ForegroundColor Cyan
    winmgmt /verifyrepository

    Write-Host ""
    Write-Host "Full WMI repair sequence complete." -ForegroundColor Green
}