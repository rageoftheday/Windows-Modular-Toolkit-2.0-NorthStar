@echo off
title WMI Fullrepair
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
