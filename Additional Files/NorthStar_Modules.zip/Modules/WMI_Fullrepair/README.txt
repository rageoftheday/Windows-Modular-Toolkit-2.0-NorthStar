WMI Fullrepair

Rebuilt from original label :wmi_fullrepair.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
