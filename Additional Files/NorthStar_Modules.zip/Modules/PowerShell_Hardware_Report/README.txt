PowerShell Hardware Report

Rebuilt from original label :ps_hwreport.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
