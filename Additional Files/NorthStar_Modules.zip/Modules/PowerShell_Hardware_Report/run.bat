@echo off
title PowerShell Hardware Report
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
