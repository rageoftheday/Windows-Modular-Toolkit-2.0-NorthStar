# ============================================================
# POWERSHELL HARDWARE REPORT
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL HARDWARE REPORT" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Full System Hardware Report:'
    Write-Host '  Comprehensive hardware inventory covering OS, CPU, RAM,'
    Write-Host '  disks, and GPU in one view. Good for documentation'
    Write-Host '  or before making hardware changes.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'hwreport.ps1'
    Set-Content -Path $f -Value 'Write-Host ''--- OS ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture,LastBootUpTime | Format-List' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- CPU ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,LoadPercentage | Format-List' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- RAM ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_PhysicalMemory | Select-Object BankLabel,@{N=''Size(GB)'';E={[math]::Round($_.Capacity/1GB,0)}},Speed,Manufacturer | Format-Table -AutoSize' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- Disk ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_DiskDrive | Select-Object Model,@{N=''Size(GB)'';E={[math]::Round($_.Size/1GB,0)}},InterfaceType,Status | Format-Table -AutoSize' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- GPU ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-CimInstance Win32_VideoController | Select-Object Name,@{N=''VRAM(GB)'';E={[math]::Round($_.AdapterRAM/1GB,1)}},DriverVersion | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
