@echo off
title Powershell Processes
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
