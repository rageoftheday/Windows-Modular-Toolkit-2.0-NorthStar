Powershell Processes

Rebuilt from original label :ps_processes.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
