# ============================================================
# POWERSHELL PROCESSES
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL PROCESSES" `
    -RequiresAdmin $false `
    -ScriptBlock {


    Show-ToolkitHeader "PROCESSES"
    Get-Process | Sort-Object CPU -Descending | Select-Object -First 25 Name, Id, CPU, WorkingSet | Format-Table -AutoSize

}
