@echo off
title MDM Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
