# ============================================================
# MDM STATUS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "MDM STATUS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'MDM / Intune / Azure AD Join Status:'
    Write-Host '  Shows whether this machine is joined to Azure AD,'
    Write-Host '  enrolled in Intune MDM, hybrid joined to on-prem AD,'
    Write-Host '  and the current compliance/registration state.'
    Write-Host '  Useful for diagnosing Intune policy or login issues.'
    Write-Host ""
    cmd.exe /c "dsregcmd /status"
    Write-Host ""
    Write-Host ""

}
