WMI Restart

Rebuilt from original label :wmi_restart.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
