# ============================================================
# WMI RESTART
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WMI RESTART" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "Restarting Windows Management Instrumentation service..." -ForegroundColor Cyan
    Restart-Service winmgmt -Force
    Write-Host "WMI service restart requested."
}
