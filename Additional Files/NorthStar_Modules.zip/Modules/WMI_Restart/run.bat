@echo off
title WMI Restart
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
