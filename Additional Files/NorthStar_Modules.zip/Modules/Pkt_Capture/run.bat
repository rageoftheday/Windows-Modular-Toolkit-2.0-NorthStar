@echo off
title Pkt Capture
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
