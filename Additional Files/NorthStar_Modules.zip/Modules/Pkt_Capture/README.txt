Pkt Capture

Rebuilt from original label :pkt_capture.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
