# ============================================================
# PKT CAPTURE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PKT CAPTURE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Packet Capture using netsh trace:'
    Write-Host '  Captures network traffic to a file without needing'
    Write-Host '  Wireshark installed. The .etl file can be converted to'
    Write-Host '  .cap format for analysis in Wireshark or Network Monitor.'
    Write-Host '  Capture is saved to C:\netcap.etl'
    Write-Host ""
    Write-Host '  1. Start capture'
    Write-Host '  2. Stop capture'
    Write-Host '  3. Cancel'
    Write-Host ""
    $pcap = Read-Host 'Select:'
    cmd.exe /c "if `"$pcap`"==`"1`" ("
    Write-Host ""
    Write-Host 'Starting capture...'
    cmd.exe /c "netsh trace start capture=yes tracefile=C:\netcap.etl"
    Write-Host ""
    cmd.exe /c ")"
    cmd.exe /c "if `"$pcap`"==`"2`" ("
    Write-Host ""
    Write-Host 'Stopping capture...'
    cmd.exe /c "netsh trace stop"
    Write-Host ""
    Write-Host 'Capture stopped. File saved: C:\netcap.etl'
    Write-Host 'To convert for Wireshark: netsh trace convert C:\netcap.etl'
    Write-Host ""
    cmd.exe /c ")"
    Write-Host ""

}
