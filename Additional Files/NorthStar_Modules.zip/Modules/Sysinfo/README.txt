Sysinfo

Rebuilt from original label :sysinfo.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
