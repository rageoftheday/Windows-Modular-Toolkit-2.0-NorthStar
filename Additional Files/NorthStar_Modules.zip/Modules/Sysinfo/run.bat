@echo off
title Sysinfo
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
