# ============================================================
# SYSINFO
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SYSINFO" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Full System Info Summary:'
    Write-Host '  Key system information pulled from Windows including'
    Write-Host '  OS details, processor, memory, domain, and boot time.'
    Write-Host ""
    cmd.exe /c "systeminfo | findstr /C:`"OS Name`" /C:`"OS Version`" /C:`"System Type`" /C:`"Total Physical Memory`" /C:`"Available Physical Memory`" /C:`"System Boot Time`" /C:`"Processor`" /C:`"Domain`" /C:`"Logon Server`""
    Write-Host ""
    Write-Host ""

}
