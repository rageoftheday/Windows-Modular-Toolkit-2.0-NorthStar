SMB Shares

Rebuilt from original label :smb_shares.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
