# ============================================================
# SMB SHARES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SMB SHARES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'SMB File Shares and Open Files:'
    Write-Host '  Shows all shared folders on this machine and open SMB files.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'smbshares.ps1'
    Set-Content -Path $f -Value 'Import-Module SmbShare -ErrorAction SilentlyContinue' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value 'Write-Host ''--- SHARED FOLDERS ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-SmbShare -ErrorAction SilentlyContinue | Format-Table -AutoSize' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value 'Write-Host ''--- OPEN FILES (remote users) ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'try {' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-SmbOpenFile -ErrorAction Stop | Format-Table -AutoSize' -Encoding UTF8
    Add-Content -Path $f -Value '} catch {' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''No access or SMB OpenFile not available (run as Admin)'' -ForegroundColor Yellow' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
