@echo off
title SMB Shares
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
