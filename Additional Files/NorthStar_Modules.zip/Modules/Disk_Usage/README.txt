Disk Usage

Rebuilt from original label :disk_usage.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
