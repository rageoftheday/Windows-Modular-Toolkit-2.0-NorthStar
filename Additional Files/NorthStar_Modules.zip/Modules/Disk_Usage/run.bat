@echo off
title Disk Usage
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
