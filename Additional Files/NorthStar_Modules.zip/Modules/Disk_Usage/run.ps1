# ============================================================
# DISK USAGE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DISK USAGE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Disk Usage - All Drives:'
    Write-Host '  Shows free space and total size for every drive letter'
    Write-Host '  on this machine. Quick way to spot full drives.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'diskusage.ps1'
    Set-Content -Path $f -Value 'Get-PSDrive -PSProvider FileSystem | Where-Object {$_.Used -ne $null} |' -Encoding UTF8
    Add-Content -Path $f -Value 'Select-Object Name,' -Encoding UTF8
    Add-Content -Path $f -Value '@{N=''Total(GB)'';E={[math]::Round(($_.Used+$_.Free)/1GB,1)}},' -Encoding UTF8
    Add-Content -Path $f -Value '@{N=''Used(GB)'';E={[math]::Round($_.Used/1GB,1)}},' -Encoding UTF8
    Add-Content -Path $f -Value '@{N=''Free(GB)'';E={[math]::Round($_.Free/1GB,1)}},' -Encoding UTF8
    Add-Content -Path $f -Value '@{N=''FreePct'';E={[math]::Round(($_.Free/($_.Used+$_.Free))*100,1)}} |' -Encoding UTF8
    Add-Content -Path $f -Value 'Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    cmd.exe /c "if errorlevel 1 echo [FAIL] PowerShell execution failed"
    Write-Host ""
    Write-Host ""

}
