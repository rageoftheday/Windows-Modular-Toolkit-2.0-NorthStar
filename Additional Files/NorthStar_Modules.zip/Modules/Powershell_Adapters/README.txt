Powershell Adapters

Rebuilt from original label :ps_adapters.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
