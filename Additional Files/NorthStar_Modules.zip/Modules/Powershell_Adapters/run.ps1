# ============================================================
# POWERSHELL ADAPTERS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL ADAPTERS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Network Adapters and IP Configuration:'
    Write-Host '  Shows all adapters with their assigned IP addresses,'
    Write-Host '  default gateways, and DNS servers. Useful for confirming'
    Write-Host '  correct network settings at a glance.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'adapters.ps1'
    Set-Content -Path $f -Value 'Get-NetIPConfiguration | Format-List InterfaceAlias,IPv4Address,IPv6Address,IPv4DefaultGateway,DNSServer' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
