@echo off
title Powershell Adapters
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
