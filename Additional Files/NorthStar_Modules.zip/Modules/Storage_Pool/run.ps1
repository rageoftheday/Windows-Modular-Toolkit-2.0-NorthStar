# ============================================================
# STORAGE POOL
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "STORAGE POOL" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "STORAGE POOL"

    Write-Host "Displays Windows storage pool information."
    Write-Host ""

    $Pools = Get-StoragePool -ErrorAction SilentlyContinue

    if (!$Pools) {
        Write-Host "No storage pools found or storage cmdlets are unavailable." -ForegroundColor Yellow
        return
    }

    $Pools |
        Select-Object FriendlyName, HealthStatus, OperationalStatus, Size, AllocatedSize |
        Format-Table -AutoSize

    Write-Host ""
    Pause-Toolkit
}
