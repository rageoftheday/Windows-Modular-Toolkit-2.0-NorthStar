@echo off
title Storage Pool
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
