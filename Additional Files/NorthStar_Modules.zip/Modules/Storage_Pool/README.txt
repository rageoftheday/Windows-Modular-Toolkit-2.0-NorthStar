Storage Pool

Rebuilt from original label :storage_pool.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
