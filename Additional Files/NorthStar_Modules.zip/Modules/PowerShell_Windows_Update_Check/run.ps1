# ============================================================
# POWERSHELL WINDOWS UPDATE CHECK
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL WINDOWS UPDATE CHECK" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Show-ToolkitHeader "POWERSHELL WINDOWS UPDATE CHECK"

    if (-not (Get-Module PSWindowsUpdate -ListAvailable)) {

        Write-Host "PSWindowsUpdate is not installed." -ForegroundColor Yellow
        $Choice = Read-Host "Install it now? (Y/N)"

        if ($Choice.ToUpper() -ne "Y") {
            Write-Host ""
            Write-Host "Cancelled."
            return
        }

        Write-Host ""
        Write-Host "Installing PSWindowsUpdate..." -ForegroundColor Cyan

        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force | Out-Null
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
        Install-Module -Name PSWindowsUpdate -Force -AllowClobber
    }

    Import-Module PSWindowsUpdate

    Write-Host ""
    Write-Host "Checking for available updates..." -ForegroundColor Cyan
    Write-Host ""

    $Updates = Get-WindowsUpdate

    if ($Updates) {

        $Updates |
            Select-Object KB, Title, Size |
            Format-Table -AutoSize

        Write-Host ""
        $Install = Read-Host "Install all $($Updates.Count) updates now? (Y/N)"

        if ($Install.ToUpper() -eq "Y") {
            Install-WindowsUpdate -AcceptAll -AutoReboot
        }
    }
    else {
        Write-Host "Your system is up to date." -ForegroundColor Green
    }
}
