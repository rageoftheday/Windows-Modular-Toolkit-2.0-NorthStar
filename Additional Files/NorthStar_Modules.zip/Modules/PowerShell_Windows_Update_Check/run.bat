@echo off
title PowerShell Windows Update Check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
