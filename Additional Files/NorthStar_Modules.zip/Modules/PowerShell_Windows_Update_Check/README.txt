PowerShell Windows Update Check

Rebuilt from original label :ps_wu_check.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
