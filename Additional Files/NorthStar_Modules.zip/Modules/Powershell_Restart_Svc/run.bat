@echo off
title Powershell Restart Svc
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
