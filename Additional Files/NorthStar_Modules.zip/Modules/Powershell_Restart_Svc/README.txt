Powershell Restart Svc

Rebuilt from original label :ps_restart_svc.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
