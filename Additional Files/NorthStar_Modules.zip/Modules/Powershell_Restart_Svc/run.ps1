# ============================================================
# POWERSHELL RESTART SVC
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL RESTART SVC" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Restart a Service by Name:'
    Write-Host '  Stops then restarts a Windows service. Use the short'
    Write-Host '  service name (not display name). Find names via the appropriate validator module.'
    Write-Host '  Example: spooler (Print Spooler), wuauserv (Windows Update)'
    Write-Host ""
    $rsvcname = Read-Host 'Enter service name to restart:'
    Write-Host ""
    cmd.exe /c "powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command `"Restart-Service -Name '$rsvcname' -ErrorAction SilentlyContinue; Write-Host 'Service restarted.' -ForegroundColor Green`""
    Write-Host ""
    Write-Host ""

}
