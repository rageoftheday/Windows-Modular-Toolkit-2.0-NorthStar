Ping Trace

Rebuilt from original label :ping_trace.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
