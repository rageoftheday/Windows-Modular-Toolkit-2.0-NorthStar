@echo off
title Ping Trace
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
