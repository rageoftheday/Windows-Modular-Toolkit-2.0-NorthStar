# ============================================================
# PING TRACE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PING TRACE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Ping + Tracert Network Test'
    Write-Host '  Ping tests if a host is reachable and measures response'
    Write-Host '  time. Tracert shows the path packets take to reach the'
    Write-Host '  destination - useful for finding where connections fail.'
    Write-Host ""
    $target = Read-Host 'Enter hostname or IP to test:'
    Write-Host ""
    Write-Host '--- PING (testing basic reachability) ---'
    cmd.exe /c "ping `"$target`""
    Write-Host ""
    Write-Host '--- TRACERT (tracing network path) ---'
    cmd.exe /c "tracert `"$target`""
    Write-Host ""
    Write-Host ""

}
