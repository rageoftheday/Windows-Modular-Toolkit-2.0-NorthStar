# ============================================================
# POWERSHELL TPM
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL TPM" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'TPM (Trusted Platform Module) Status:'
    Write-Host '  TPM is a security chip required for Windows 11 and'
    Write-Host '  features like BitLocker and Windows Hello.'
    Write-Host '  TpmPresent=True and TpmReady=True is ideal.'
    Write-Host '  TpmVersion should be 2.0 for Windows 11.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'tpm.ps1'
    Set-Content -Path $f -Value 'Get-Tpm | Format-List' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
