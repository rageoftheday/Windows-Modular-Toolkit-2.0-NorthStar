@echo off
title Powershell TPM
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
