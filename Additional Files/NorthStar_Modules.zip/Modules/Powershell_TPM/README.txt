Powershell TPM

Rebuilt from original label :ps_tpm.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
