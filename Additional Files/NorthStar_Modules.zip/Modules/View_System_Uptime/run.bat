@echo off
title View System Uptime
color 0B
cls
echo ============================================================
echo View System Uptime
echo ============================================================
echo.
echo Shows how long the system has been running.
echo.
echo Demo module executed successfully.
echo.
pause
