@echo off
title Powershell Routes
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
