# ============================================================
# POWERSHELL ROUTES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL ROUTES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'IP Routing Table:'
    Write-Host '  Shows all routes the machine uses to direct network'
    Write-Host '  traffic. The default route (0.0.0.0/0) points to your'
    Write-Host '  gateway. Multiple default routes can cause issues.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'routes.ps1'
    Set-Content -Path $f -Value 'Get-NetRoute | Sort-Object RouteMetric | Format-Table DestinationPrefix,NextHop,InterfaceAlias,RouteMetric -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
