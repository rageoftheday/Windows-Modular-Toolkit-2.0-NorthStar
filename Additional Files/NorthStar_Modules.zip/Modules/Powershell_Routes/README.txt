Powershell Routes

Rebuilt from original label :ps_routes.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
