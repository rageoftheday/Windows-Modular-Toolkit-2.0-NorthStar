Powershell FW Status

Rebuilt from original label :ps_fw_status.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
