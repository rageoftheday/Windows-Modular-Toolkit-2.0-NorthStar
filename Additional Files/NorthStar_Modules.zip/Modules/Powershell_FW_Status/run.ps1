# ============================================================
# POWERSHELL FW STATUS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL FW STATUS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Windows Firewall Profile Status:'
    Write-Host '  Shows whether the firewall is on for each network profile'
    Write-Host '  (Domain, Private, Public) and default inbound/outbound'
    Write-Host '  actions. All three should typically be enabled.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'fwstatus.ps1'
    Set-Content -Path $f -Value 'Get-NetFirewallProfile | Format-Table Name,Enabled,DefaultInboundAction,DefaultOutboundAction -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
