@echo off
title Powershell FW Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
