@echo off
title Port Test
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
