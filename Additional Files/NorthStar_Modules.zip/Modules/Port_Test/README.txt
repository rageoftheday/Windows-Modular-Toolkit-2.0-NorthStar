Port Test

Rebuilt from original label :port_test.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
