# ============================================================
# PORT TEST
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PORT TEST" `
    -RequiresAdmin $false `
    -ScriptBlock {


    Show-ToolkitHeader "PORT TEST"
    $HostName = Read-Host "Enter host"
    $Port = Read-Host "Enter port"
    if ([string]::IsNullOrWhiteSpace($HostName) -or [string]::IsNullOrWhiteSpace($Port)) { return }
    Test-NetConnection -ComputerName $HostName -Port ([int]$Port)

}
