@echo off
title Recent Files
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
