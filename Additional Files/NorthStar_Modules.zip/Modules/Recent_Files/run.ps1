# ============================================================
# RECENT FILES
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "RECENT FILES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "RECENT FILES"

    $RecentPath = Join-Path $env:APPDATA "Microsoft\Windows\Recent"

    if (!(Test-Path $RecentPath)) {
        Write-Host "Recent files folder not found." -ForegroundColor Yellow
        return
    }

    Get-ChildItem $RecentPath -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 50 Name, LastWriteTime, FullName |
        Format-Table -AutoSize

    Write-Host ""
    Pause-Toolkit
}
