Recent Files

Rebuilt from original label :recent_files.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
