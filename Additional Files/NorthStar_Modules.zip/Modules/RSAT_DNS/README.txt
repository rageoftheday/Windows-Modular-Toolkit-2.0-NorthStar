RSAT DNS

Rebuilt from original label :rsat_dns.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
