@echo off
title RSAT DNS
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
