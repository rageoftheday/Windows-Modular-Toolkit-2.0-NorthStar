# ============================================================
# NET INFO
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "NET INFO" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Network Information:'
    Write-Host '  Shows all network adapters, IP addresses, subnet masks,'
    Write-Host '  default gateways, DNS servers, and MAC addresses.'
    Write-Host ""
    cmd.exe /c "ipconfig /all"
    Write-Host ""
    Write-Host ""

}
