@echo off
title Net Info
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
