@echo off
title Powershell Modules
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
