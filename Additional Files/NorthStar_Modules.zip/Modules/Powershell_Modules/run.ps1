# ============================================================
# POWERSHELL MODULES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL MODULES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Installed PowerShell Modules:'
    Write-Host '  Lists all PowerShell modules installed on this machine.'
    Write-Host '  Modules add extra commands to PowerShell. If a command'
    Write-Host '  is not found, the module providing it may not be installed.'
    Write-Host '  Install missing modules via Section 0.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'psmodules.ps1'
    Set-Content -Path $f -Value 'Get-Module -ListAvailable | Select-Object Name,Version,ModuleType | Sort-Object Name | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
