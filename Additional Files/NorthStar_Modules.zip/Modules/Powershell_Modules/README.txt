Powershell Modules

Rebuilt from original label :ps_modules.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
