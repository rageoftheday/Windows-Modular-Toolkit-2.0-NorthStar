WSL Shell

Rebuilt from original label :wsl_shell.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
