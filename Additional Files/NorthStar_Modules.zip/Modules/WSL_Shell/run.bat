@echo off
title WSL Shell
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
