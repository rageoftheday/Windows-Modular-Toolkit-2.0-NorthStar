@echo off
title Installed Updates
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
