# ============================================================
# INSTALLED UPDATES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "INSTALLED UPDATES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Installed Windows Updates:'
    Write-Host '  Lists all Windows Updates installed on this machine'
    Write-Host '  with KB numbers and install dates. Useful for checking'
    Write-Host '  if a specific security patch has been applied.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'installedupdates.ps1'
    Set-Content -Path $f -Value 'Get-HotFix | Sort-Object InstalledOn -Descending |' -Encoding UTF8
    Add-Content -Path $f -Value 'Select-Object HotFixID,Description,InstalledBy,InstalledOn |' -Encoding UTF8
    Add-Content -Path $f -Value 'Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
