Installed Updates

Rebuilt from original label :installed_updates.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
