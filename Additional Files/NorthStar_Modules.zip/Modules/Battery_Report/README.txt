Battery Report

Rebuilt from original label :battery_report.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
