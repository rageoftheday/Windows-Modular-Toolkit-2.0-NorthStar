@echo off
title Battery Report
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
