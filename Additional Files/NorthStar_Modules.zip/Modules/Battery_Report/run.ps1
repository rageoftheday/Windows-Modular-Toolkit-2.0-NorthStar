# ============================================================
# BATTERY REPORT
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "BATTERY REPORT" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Generating Battery Report...'
    Write-Host '  Creates a detailed HTML report showing battery health,'
    Write-Host '  capacity history, and usage patterns over time.'
    Write-Host '  Design capacity vs full charge capacity shows battery wear.'
    Write-Host '  Report saved to Desktop as battery_report.html.'
    Write-Host ""
    cmd.exe /c "powercfg /batteryreport /output `"$env:USERPROFILE\Desktop\battery_report.html`""
    Write-Host ""
    Write-Host 'Report saved to Desktop. Open it in any web browser.'
    Write-Host ""

}
