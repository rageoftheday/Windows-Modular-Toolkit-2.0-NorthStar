# ============================================================
# POWERSHELL FOLDER SIZE
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL FOLDER SIZE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $Path = Read-Host "Enter folder path"

    if ([string]::IsNullOrWhiteSpace($Path) -or !(Test-Path $Path)) {
        Write-Host "Invalid path." -ForegroundColor Red
        return
    }

    $Size = Get-ChildItem $Path -Recurse -Force -ErrorAction SilentlyContinue |
        Measure-Object Length -Sum

    Write-Host ""
    Write-Host "Folder: $Path"
    Write-Host "Size  : $([math]::Round($Size.Sum / 1GB, 2)) GB"
    Write-Host ""
}
