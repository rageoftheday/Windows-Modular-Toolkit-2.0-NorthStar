@echo off
title Powershell Folder Size
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
