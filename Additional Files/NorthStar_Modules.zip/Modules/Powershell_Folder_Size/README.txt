Powershell Folder Size

Rebuilt from original label :ps_folder_size.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
