@echo off
title VSS List
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
