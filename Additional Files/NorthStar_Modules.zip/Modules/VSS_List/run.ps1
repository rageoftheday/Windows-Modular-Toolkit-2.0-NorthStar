# ============================================================
# VSS LIST
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "VSS LIST" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Volume Shadow Copies (VSS):'
    Write-Host '  Shadow copies are automatic snapshots Windows takes of'
    Write-Host '  files. They allow previous versions of files to be'
    Write-Host '  restored. Lists existing snapshots and VSS writer status.'
    Write-Host '  Writers in a failed state can prevent backups working.'
    Write-Host ""
    Write-Host '--- Shadow Copy Snapshots ---'
    cmd.exe /c "vssadmin list shadows"
    Write-Host ""
    Write-Host '--- VSS Writer Status ---'
    cmd.exe /c "vssadmin list writers"
    Write-Host ""
    Write-Host ""

}
