VSS List

Rebuilt from original label :vss_list.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
