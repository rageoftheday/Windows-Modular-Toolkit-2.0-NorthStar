# ============================================================
# LAST LOGONS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "LAST LOGONS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Last Logon Time for All Local Users:'
    Write-Host '  Shows when each local account last logged in, password'
    Write-Host '  dates, and whether the account is enabled. Useful for'
    Write-Host '  finding stale or unused accounts to disable.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'lastlogons.ps1'
    Set-Content -Path $f -Value 'Get-LocalUser | Select-Object Name,Enabled,LastLogon,PasswordLastSet,PasswordExpires | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
