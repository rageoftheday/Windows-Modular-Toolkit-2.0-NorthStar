@echo off
title Last Logons
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
