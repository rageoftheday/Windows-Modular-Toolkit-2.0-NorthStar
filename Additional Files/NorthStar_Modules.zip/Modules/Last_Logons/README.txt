Last Logons

Rebuilt from original label :last_logons.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
