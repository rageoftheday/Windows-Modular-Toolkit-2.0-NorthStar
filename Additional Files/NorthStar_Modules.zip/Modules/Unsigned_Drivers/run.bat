@echo off
title Unsigned Drivers
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
