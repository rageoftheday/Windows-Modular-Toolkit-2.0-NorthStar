Unsigned Drivers

Rebuilt from original label :unsigned_drivers.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
