# ============================================================
# UNSIGNED DRIVERS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "UNSIGNED DRIVERS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Non-Microsoft / Third-Party Driver Check:'
    Write-Host '  Lists all drivers not provided by Microsoft. Third-party'
    Write-Host '  drivers are a common cause of BSODs and instability.'
    Write-Host '  Review this list after hardware installs or BSODs.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'unsigneddrivers.ps1'
    Set-Content -Path $f -Value 'Get-WindowsDriver -Online -All | Where-Object {$_.ProviderName -notlike ''*Microsoft*''} |' -Encoding UTF8
    Add-Content -Path $f -Value 'Select-Object Driver,ProviderName,Date,Version | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
