# ============================================================
# WIFI PASSWORDS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WIFI PASSWORDS" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Saved Wi-Fi Profiles and Passwords:'
    Write-Host '  Shows all Wi-Fi networks saved on this machine and'
    Write-Host '  their stored passwords. Useful when a user has forgotten'
    Write-Host '  a Wi-Fi password that was previously connected.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'wifipass.ps1'
    Set-Content -Path $f -Value '$profiles = (netsh wlan show profiles) | Select-String "All User Profile" | ForEach-Object { ($_ -split ":",2)[1].Trim() }' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value 'if (-not $profiles) {' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host "No Wi-Fi profiles found or Wi-Fi adapter not present." -ForegroundColor Yellow' -Encoding UTF8
    Add-Content -Path $f -Value 'exit' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value 'foreach ($ssid in $profiles) {' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ("Profile: " + $ssid) -ForegroundColor Cyan' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value '$output = netsh wlan show profile name="$ssid" key=clear | Out-String' -Encoding UTF8
    Add-Content -Path $f -Value '$line = ($output -split "`n" | Select-String "Key Content")' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value 'if ($line) {' -Encoding UTF8
    Add-Content -Path $f -Value '$password = ($line.ToString() -split ":")[1].Trim()' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ("  Password: " + $password) -ForegroundColor Green' -Encoding UTF8
    Add-Content -Path $f -Value '} else {' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host "  (no password stored or open network)" -ForegroundColor Gray' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    cmd.exe /c ">> `"$f`" echo."
    Add-Content -Path $f -Value '}' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    cmd.exe /c "if errorlevel 1 echo [FAIL] PowerShell execution failed"
    Write-Host ""
    Write-Host ""

}
