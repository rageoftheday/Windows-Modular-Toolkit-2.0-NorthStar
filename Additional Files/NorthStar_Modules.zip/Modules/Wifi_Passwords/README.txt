Wifi Passwords

Rebuilt from original label :wifi_passwords.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
