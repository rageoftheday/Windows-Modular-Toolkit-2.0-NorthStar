@echo off
title Wifi Passwords
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
