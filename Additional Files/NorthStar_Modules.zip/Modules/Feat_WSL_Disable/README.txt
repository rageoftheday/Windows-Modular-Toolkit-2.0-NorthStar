Feat WSL Disable

Rebuilt from original label :feat_wsl_disable.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
