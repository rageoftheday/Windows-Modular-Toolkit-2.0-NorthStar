@echo off
title Feat WSL Disable
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
