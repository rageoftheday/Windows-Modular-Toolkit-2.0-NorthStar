# ============================================================
# FEAT WSL DISABLE
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FEAT WSL DISABLE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "Disabling WSL feature..." -ForegroundColor Cyan
    Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -NoRestart
    Write-Host "WSL disable request completed. Reboot may be required."
}
