# ============================================================
# WMI VERIFY
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WMI VERIFY" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Verifying WMI Repository...'
    Write-Host '  WMI (Windows Management Instrumentation) is the system'
    Write-Host '  Windows uses to report hardware and software info to'
    Write-Host '  tools. If it is broken, many diagnostics will fail.'
    Write-Host ""
    cmd.exe /c "winmgmt /verifyrepository"
    Write-Host ""
    Write-Host 'If result says not consistent, run the appropriate validator module to rebuild.'
    Write-Host ""

}
