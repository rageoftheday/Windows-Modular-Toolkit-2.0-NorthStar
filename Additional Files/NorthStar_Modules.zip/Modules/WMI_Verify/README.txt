WMI Verify

Rebuilt from original label :wmi_verify.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
