# ============================================================
# POWERSHELL EVENTLOG
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL EVENTLOG" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Write-Host "--- RECENT SYSTEM ERRORS ---" -ForegroundColor Cyan

    Get-WinEvent -LogName System -MaxEvents 50 -ErrorAction SilentlyContinue |
        Where-Object { $_.LevelDisplayName -in @("Error", "Critical") } |
        Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, Message |
        Format-Table -Wrap

    Write-Host ""
}
