@echo off
title Powershell Eventlog
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
