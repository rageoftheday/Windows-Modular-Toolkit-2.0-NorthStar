Powershell Eventlog

Rebuilt from original label :ps_eventlog.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
