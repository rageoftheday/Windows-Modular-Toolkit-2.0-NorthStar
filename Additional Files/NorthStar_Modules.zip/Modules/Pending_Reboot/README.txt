Pending Reboot

Rebuilt from original label :pending_reboot.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
