# ============================================================
# PENDING REBOOT
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PENDING REBOOT" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Checking for Pending Reboot Flags:'
    Write-Host '  Checks registry keys that Windows sets when a reboot'
    Write-Host '  is required. A pending reboot can cause update failures,'
    Write-Host '  install errors, and other unexpected behaviour.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'pendingreboot.ps1'
    Set-Content -Path $f -Value '$flags = @()' -Encoding UTF8
    Add-Content -Path $f -Value 'if (Test-Path ''HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'') { $flags += ''CBS: Component-based servicing requires a reboot'' }' -Encoding UTF8
    Add-Content -Path $f -Value 'if (Test-Path ''HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'') { $flags += ''Windows Update: Reboot required to finish installing updates'' }' -Encoding UTF8
    Add-Content -Path $f -Value 'if (Test-Path ''HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\PendingFileRenameOperations'') { $flags += ''File Rename Operations: Files waiting to be moved or deleted on next boot'' }' -Encoding UTF8
    Add-Content -Path $f -Value 'if ($flags.Count -eq 0) { Write-Host ''No pending reboot detected. Machine is clean.'' -ForegroundColor Green }' -Encoding UTF8
    Add-Content -Path $f -Value 'else { Write-Host ''PENDING REBOOT DETECTED:'' -ForegroundColor Yellow; $flags | ForEach-Object { Write-Host (''  - '' + $_) -ForegroundColor Yellow } }' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
