@echo off
title Pending Reboot
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
