
@echo off
title Clear Windows Update Cache
color 0B
cls

echo ============================================================
echo              CLEAR WINDOWS UPDATE CACHE
echo ============================================================
echo.

net stop wuauserv >nul 2>&1
net stop bits >nul 2>&1

rd /s /q "C:\Windows\SoftwareDistribution" >nul 2>&1

net start wuauserv >nul 2>&1
net start bits >nul 2>&1

echo Windows Update cache cleanup completed.
echo.
pause
