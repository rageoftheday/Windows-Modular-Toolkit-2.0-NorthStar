Powershell Inet Test

Rebuilt from original label :ps_inet_test.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
