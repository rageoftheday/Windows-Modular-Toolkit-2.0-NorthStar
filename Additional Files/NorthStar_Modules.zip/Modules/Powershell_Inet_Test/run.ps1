# ============================================================
# POWERSHELL Internet Connectivity Test
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL INET TEST" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Write-Host "Internet Connectivity Test:"
    Write-Host "  Tests two DNS servers and two hostnames."
    Write-Host "  If IPs work but hostnames fail, DNS is likely the issue."
    Write-Host ""

    $Targets = @(
        "8.8.8.8",
        "1.1.1.1",
        "google.com",
        "microsoft.com"
    )

    foreach ($Target in $Targets) {

        $Result = Test-NetConnection `
            -ComputerName $Target `
            -WarningAction SilentlyContinue

        if ($Result.PingSucceeded) {
            Write-Host "$($Target.PadRight(20)) OK - reachable" -ForegroundColor Green
        }
        else {
            Write-Host "$($Target.PadRight(20)) FAIL - unreachable" -ForegroundColor Red
        }
    }

    Write-Host ""
}