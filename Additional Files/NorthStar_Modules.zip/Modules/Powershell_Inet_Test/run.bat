@echo off
title Powershell Inet Test
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
