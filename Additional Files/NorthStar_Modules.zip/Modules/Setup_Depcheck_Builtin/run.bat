@echo off
title Setup Depcheck Builtin
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
