Setup Depcheck Builtin

Rebuilt from original label :setup_depcheck_builtin.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
