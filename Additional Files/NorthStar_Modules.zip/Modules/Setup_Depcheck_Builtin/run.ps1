# ============================================================
# SETUP DEPCHECK BUILTIN
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SETUP DEPCHECK BUILTIN" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Checking Windows Built-in Features...'
    Write-Host '(RSAT tools, WMI health, Hyper-V, WSL - no external tools needed)'
    Write-Host ""
    $f = Join-Path $env:TEMP 'depcheck_builtin.ps1'
    cmd.exe /c "powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^"
    cmd.exe /c "`"$lines = @(`" ^"
    cmd.exe /c "`"  '$pass = 0; $fail = 0',`" ^"
    cmd.exe /c "`"  'function Show($label, $ok) {',`" ^"
    cmd.exe /c "`"  '  if ($ok) { Write-Host (\`"[PASS]  \`" + $label) -ForegroundColor Green; $script:pass++ }',`" ^"
    cmd.exe /c "`"  '  else     { Write-Host (\`"[FAIL]  \`" + $label) -ForegroundColor Red;  $script:fail++ }',`" ^"
    cmd.exe /c "`"  '}',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Write-Host \`" WINDOWS BUILT-IN FEATURES\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- WMI HEALTH ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"WMI Service running\`"     ((Get-Service Winmgmt -EA SilentlyContinue).Status -eq \`"Running\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WMI Repository OK\`"       ((winmgmt /verifyrepository 2>`$null) -match \`"consistent\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: OS query works\`"     ([bool](Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: Disk query works\`"   ([bool](Get-CimInstance Win32_DiskDrive -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: RAM query works\`"    ([bool](Get-CimInstance Win32_PhysicalMemory -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Show \`"WMI: CPU query works\`"    ([bool](Get-CimInstance Win32_Processor -EA SilentlyContinue))',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- RSAT TOOLS ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: AD DS Tools\`"       ((Get-WindowsCapability -Online -Name \`"Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: DNS Tools\`"         ((Get-WindowsCapability -Online -Name \`"Rsat.Dns.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: GP Management\`"     ((Get-WindowsCapability -Online -Name \`"Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Show \`"RSAT: Hyper-V Tools\`"     ((Get-WindowsCapability -Online -Name \`"Rsat.HyperV.Tools~~~~0.0.1.0\`" -EA SilentlyContinue).State -eq \`"Installed\`")',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"--- WINDOWS FEATURES ---\`" -ForegroundColor White',`" ^"
    cmd.exe /c "`"  'Show \`"Hyper-V enabled\`"         ((Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -EA SilentlyContinue).State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  'Show \`"WSL enabled\`"             ((Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -EA SilentlyContinue).State -eq \`"Enabled\`")',`" ^"
    cmd.exe /c "`"  'Write-Host \`"\`"',`" ^"
    cmd.exe /c "`"  '',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`" -ForegroundColor Cyan',`" ^"
    cmd.exe /c "`"  'if ($fail -eq 0) { Write-Host \`" RESULT: All `$pass built-in checks passed.\`" -ForegroundColor Green }',`" ^"
    cmd.exe /c "`"  'else             { Write-Host \`" RESULT: `$pass passed, `$fail failed. Run Section 0 options 15-21 to fix.\`" -ForegroundColor Yellow }',`" ^"
    cmd.exe /c "`"  'Write-Host \`"============================\`"  -ForegroundColor Cyan'`" ^"
    cmd.exe /c "`"); Set-Content -Path '$f' -Value ($lines -join \`"`n\`") -Encoding UTF8`""
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
