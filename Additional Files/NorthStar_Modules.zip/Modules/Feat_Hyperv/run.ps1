# ============================================================
# FEAT HYPERV
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FEAT HYPERV" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "Enabling Hyper-V..." -ForegroundColor Cyan
    Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All -NoRestart
    Write-Host "Hyper-V enable request completed. Reboot may be required."
}
