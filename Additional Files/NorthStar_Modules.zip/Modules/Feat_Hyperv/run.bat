@echo off
title Feat Hyperv
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
