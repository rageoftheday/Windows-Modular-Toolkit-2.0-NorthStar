Feat Hyperv

Rebuilt from original label :feat_hyperv.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
