@echo off
title Wsreset
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
