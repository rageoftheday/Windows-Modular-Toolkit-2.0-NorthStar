Wsreset

Rebuilt from original label :wsreset.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
