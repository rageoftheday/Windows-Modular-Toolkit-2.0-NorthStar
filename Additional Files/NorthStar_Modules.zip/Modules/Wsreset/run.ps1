# ============================================================
# WSRESET
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WSRESET" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Resetting Windows Store and AppX cache...'
    Write-Host '  Clears the Windows Store cache which can fix:'
    Write-Host '  - Store apps not opening or crashing'
    Write-Host '  - Store not loading or showing errors'
    Write-Host '  - App install failures from the Store'
    Write-Host '  A Store window will open briefly then close - this is normal.'
    Write-Host ""
    cmd.exe /c "wsreset.exe"
    Write-Host ""
    Write-Host 'Windows Store reset complete.'
    Write-Host ""

}
