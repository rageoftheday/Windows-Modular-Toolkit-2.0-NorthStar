@echo off
title Proxy Check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
