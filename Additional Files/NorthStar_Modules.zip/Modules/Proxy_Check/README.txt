Proxy Check

Rebuilt from original label :proxy_check.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
