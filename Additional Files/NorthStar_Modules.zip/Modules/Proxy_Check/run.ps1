# ============================================================
# PROXY CHECK
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PROXY CHECK" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Proxy Settings Check:'
    Write-Host '  Shows the current proxy configuration for both WinHTTP'
    Write-Host '  (used by system and apps) and the user-level proxy'
    Write-Host '  (used by browsers). Misconfigured proxies are a common'
    Write-Host '  cause of connectivity issues in corporate environments.'
    Write-Host ""
    Write-Host '--- WinHTTP Proxy (system level) ---'
    cmd.exe /c "netsh winhttp show proxy"
    Write-Host ""
    Write-Host '--- User Proxy (registry) ---'
    cmd.exe /c "reg query `"HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`" /v ProxyEnable 2>nul"
    cmd.exe /c "reg query `"HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`" /v ProxyServer 2>nul"
    Write-Host ""
    Write-Host ""

}
