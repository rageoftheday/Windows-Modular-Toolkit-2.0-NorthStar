@echo off
title Hyperv Status
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
