# ============================================================
# HYPERV STATUS
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "HYPERV STATUS" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "--- HYPER-V FEATURE STATUS ---" -ForegroundColor Cyan

    Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All |
        Select-Object FeatureName, State |
        Format-Table -AutoSize
}
