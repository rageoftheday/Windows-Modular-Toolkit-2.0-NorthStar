@echo off
title Powershell Stopped Svcs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
