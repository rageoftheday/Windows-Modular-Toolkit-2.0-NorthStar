Powershell Stopped Svcs

Rebuilt from original label :ps_stopped_svcs.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
