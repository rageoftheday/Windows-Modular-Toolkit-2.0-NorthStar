# ============================================================
# POWERSHELL STOPPED SVCS
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL STOPPED SVCS" `
    -RequiresAdmin $false `
    -ScriptBlock {


    Show-ToolkitHeader "SERVICES"
    Get-Service | Sort-Object Status, Name | Format-Table -AutoSize

}
