# ============================================================
# FW RULES
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "FW RULES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'All Enabled Firewall Rules:'
    Write-Host '  Dumps every active Windows Firewall rule. Useful for'
    Write-Host '  auditing what is allowed through the firewall or finding'
    Write-Host '  rules added by software that should not be there.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'fwrules.ps1'
    Set-Content -Path $f -Value 'Get-NetFirewallRule | Where-Object {$_.Enabled -eq ''True''} |' -Encoding UTF8
    Add-Content -Path $f -Value 'Select-Object DisplayName,Direction,Action,Profile | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
