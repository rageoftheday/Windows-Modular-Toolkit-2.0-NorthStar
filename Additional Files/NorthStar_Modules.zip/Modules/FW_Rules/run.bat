@echo off
title FW Rules
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
