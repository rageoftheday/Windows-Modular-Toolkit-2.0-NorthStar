FW Rules

Rebuilt from original label :fw_rules.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
