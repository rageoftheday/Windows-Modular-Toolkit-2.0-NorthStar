# ============================================================
# CLEAR DELOPT
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CLEAR DELOPT" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Clearing Delivery Optimization cache...'
    Write-Host '  Removes files used by Windows Update peer-to-peer'
    Write-Host '  delivery. Can free significant space on managed PCs.'
    cmd.exe /c "del /q /f /s `"C:\Windows\SoftwareDistribution\DeliveryOptimization\*`" >nul 2>&1"
    Write-Host 'Done.'
    Write-Host ""

}
