Clear Delopt

Rebuilt from original label :clear_delopt.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
