@echo off
title Clear Delopt
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
