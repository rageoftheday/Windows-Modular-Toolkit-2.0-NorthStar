@echo off
title Check Disk Fix
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
