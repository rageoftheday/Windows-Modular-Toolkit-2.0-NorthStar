# ============================================================
# CHECK DISK FIX
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CHECK DISK FIX" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'CHKDSK /F - Schedule Fix on Next Reboot'
    Write-Host '  This schedules a disk check that runs BEFORE Windows'
    Write-Host '  loads on the next restart. It can fix file system'
    Write-Host '  errors that cannot be repaired while Windows is running.'
    Write-Host '  The machine will need to reboot to complete the fix.'
    Write-Host ""
    $chkdrive = Read-Host 'Enter drive letter to check (default: C):'
    cmd.exe /c "if `"$chkdrive`"==`"`" set `"chkdrive=C`""
    $confirm = Read-Host 'Schedule CHKDSK fix on %chkdrive%: on next reboot? (Y/N):'
    Write-Host 'Y| chkdsk %chkdrive%: /F /R'
    Write-Host 'Repair: CHKDSK /F /R scheduled on %chkdrive%: at %time% >> "%LOGFILE%" 2>nul'
    Write-Host ""
    Write-Host 'CHKDSK fix scheduled. It will run on next restart.'
    Write-Host ""

}
