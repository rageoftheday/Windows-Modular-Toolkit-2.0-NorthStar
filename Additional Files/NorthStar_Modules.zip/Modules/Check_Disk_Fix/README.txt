Check Disk Fix

Rebuilt from original label :chkdsk_fix.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
