# ============================================================
# POWERSHELL BATTERY
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL BATTERY" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Write-Host "--- BATTERY STATUS ---" -ForegroundColor Cyan

    $Battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue

    if ($Battery) {
        $Battery |
            Select-Object `
                Name,
                BatteryStatus,
                EstimatedChargeRemaining,
                EstimatedRunTime |
            Format-Table -AutoSize
    }
    else {
        Write-Host "No battery detected or battery data unavailable." -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "Generating battery report..."
    $Out = Join-Path $Root "exports\battery-report.html"

    if (!(Test-Path (Join-Path $Root "exports"))) {
        New-Item -ItemType Directory -Path (Join-Path $Root "exports") | Out-Null
    }

    powercfg /batteryreport /output "$Out" | Out-Null

    if (Test-Path $Out) {
        Write-Host "Battery report saved:"
        Write-Host $Out
    }
}
