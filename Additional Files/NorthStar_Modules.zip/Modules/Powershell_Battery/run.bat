@echo off
title Powershell Battery
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
