Powershell Battery

Rebuilt from original label :ps_battery.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
