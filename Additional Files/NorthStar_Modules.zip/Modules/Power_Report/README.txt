Power Report

Rebuilt from original label :power_report.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
