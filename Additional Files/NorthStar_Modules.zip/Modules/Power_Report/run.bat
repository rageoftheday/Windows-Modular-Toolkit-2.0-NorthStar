@echo off
title Power Report
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
