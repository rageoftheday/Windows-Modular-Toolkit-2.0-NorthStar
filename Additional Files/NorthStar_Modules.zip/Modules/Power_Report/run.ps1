# ============================================================
# POWER REPORT
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWER REPORT" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Generating Power Efficiency Report (60 second trace)...'
    Write-Host '  Records system power activity for 60 seconds and'
    Write-Host '  generates a report identifying power issues, devices'
    Write-Host '  preventing sleep, and efficiency recommendations.'
    Write-Host '  Report saved to Desktop as power_report.html.'
    Write-Host '  Please wait 60 seconds...'
    Write-Host ""
    cmd.exe /c "powercfg /energy /output `"$env:USERPROFILE\Desktop\power_report.html`""
    Write-Host ""
    Write-Host 'Report saved to Desktop. Open it in any web browser.'
    Write-Host ""

}
