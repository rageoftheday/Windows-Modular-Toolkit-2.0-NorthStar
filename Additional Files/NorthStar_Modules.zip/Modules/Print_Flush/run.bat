@echo off
title Print Flush
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
