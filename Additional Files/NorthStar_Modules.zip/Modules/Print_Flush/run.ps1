# ============================================================
# PRINT FLUSH
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PRINT FLUSH" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Flush Print Queue - Clear All Stuck Print Jobs:'
    Write-Host '  Stops the Print Spooler service, removes all pending'
    Write-Host '  print jobs, then restarts the spooler. Use this when'
    Write-Host '  a printer is stuck and jobs cannot be cancelled normally.'
    Write-Host '  Any documents waiting to print will be lost.'
    Write-Host ""
    $confirm = Read-Host 'Clear all print jobs and restart spooler? (Y/N):'
    Write-Host ""
    Write-Host 'Stopping Print Spooler...'
    cmd.exe /c "net stop spooler >nul 2>&1"
    Write-Host 'Clearing print queue...'
    cmd.exe /c "del /q /f /s `"$SystemRoot\System32\spool\PRINTERS\*`" >nul 2>&1"
    Write-Host 'Restarting Print Spooler...'
    cmd.exe /c "net start spooler >nul 2>&1"
    Write-Host ""
    Write-Host 'Print queue cleared and spooler restarted.'
    Write-Host ""

}
