Print Flush

Rebuilt from original label :print_flush.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
