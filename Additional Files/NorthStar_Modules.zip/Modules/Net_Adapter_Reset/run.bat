@echo off
title Net Adapter Reset
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
