Net Adapter Reset

Rebuilt from original label :net_adapter_reset.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
