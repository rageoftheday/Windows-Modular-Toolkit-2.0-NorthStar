# ============================================================
# NET ADAPTER RESET
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "NET ADAPTER RESET" `
    -RequiresAdmin $true `
    -ScriptBlock {


    Show-ToolkitHeader "NETWORK RESET"
    netsh winsock reset
    netsh int ip reset
    ipconfig /flushdns

}
