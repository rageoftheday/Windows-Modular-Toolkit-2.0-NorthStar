WMI Reregister

Rebuilt from original label :wmi_reregister.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
