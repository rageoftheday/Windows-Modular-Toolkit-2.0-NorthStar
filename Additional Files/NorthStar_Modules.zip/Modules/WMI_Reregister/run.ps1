# ============================================================
# WMI REREGISTER
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WMI REREGISTER" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Show-ToolkitHeader "WMI REREGISTER"

    Write-Host "Re-registers WMI MOF/MFL files and WBEM DLL components."
    Write-Host ""

    $Confirm = Read-Host "Proceed with WMI re-registration? (Y/N)"

    if ($Confirm.ToUpper() -ne "Y") {
        Write-Host "Cancelled."
        return
    }

    $WmiPath = Join-Path $env:WINDIR "System32\wbem"

    Write-Host ""
    Write-Host "Compiling MOF files..." -ForegroundColor Cyan

    Get-ChildItem $WmiPath -Filter "*.mof" -ErrorAction SilentlyContinue |
        ForEach-Object {
            mofcomp $_.FullName | Out-Null
        }

    Write-Host "Compiling MFL files..." -ForegroundColor Cyan

    Get-ChildItem $WmiPath -Filter "*.mfl" -ErrorAction SilentlyContinue |
        ForEach-Object {
            mofcomp $_.FullName | Out-Null
        }

    Write-Host "Registering WBEM DLL files..." -ForegroundColor Cyan

    Get-ChildItem $WmiPath -Filter "*.dll" -ErrorAction SilentlyContinue |
        ForEach-Object {
            regsvr32 /s $_.FullName
        }

    Write-Host ""
    Write-Host "WMI component re-registration complete." -ForegroundColor Green

    Write-Host ""
    Pause-Toolkit
}
