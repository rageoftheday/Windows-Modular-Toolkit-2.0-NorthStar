@echo off
title WMI Reregister
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
