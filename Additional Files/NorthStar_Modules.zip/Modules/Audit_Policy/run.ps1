# ============================================================
# AUDIT POLICY
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "AUDIT POLICY" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Current Audit Policy:'
    Write-Host '  Shows what security events Windows is configured to log.'
    Write-Host '  If failed logons are not appearing in Event Viewer,'
    Write-Host '  check here that Account Logon auditing is enabled.'
    Write-Host ""
    cmd.exe /c "auditpol /get /category:*"
    Write-Host ""
    Write-Host ""

}
