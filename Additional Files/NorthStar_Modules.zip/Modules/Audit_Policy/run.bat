@echo off
title Audit Policy
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
