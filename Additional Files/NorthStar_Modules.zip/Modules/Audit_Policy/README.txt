Audit Policy

Rebuilt from original label :audit_policy.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
