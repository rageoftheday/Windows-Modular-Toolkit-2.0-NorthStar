@echo off
title PowerShell Windows Update Install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
