# ============================================================
# POWERSHELL WINDOWS UPDATE INSTALL
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL WINDOWS UPDATE INSTALL" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Show-ToolkitHeader "POWERSHELL WINDOWS UPDATE INSTALL"

    if (-not (Get-Module PSWindowsUpdate -ListAvailable)) {
        Write-Host "PSWindowsUpdate is not installed." -ForegroundColor Yellow
        $Choice = Read-Host "Install it now? (Y/N)"

        if ($Choice.ToUpper() -ne "Y") {
            Write-Host ""
            Write-Host "Cancelled."
            return
        }

        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force | Out-Null
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
        Install-Module -Name PSWindowsUpdate -Force -AllowClobber
    }

    Import-Module PSWindowsUpdate

    Write-Host "Installing available Windows updates..." -ForegroundColor Cyan
    Install-WindowsUpdate -AcceptAll -AutoReboot
}
