PowerShell Windows Update Install

Rebuilt from original label :ps_wu_install.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
