
@echo off
title Clear Thumbnail Cache
color 0B
cls

echo ============================================================
echo                 CLEAR THUMBNAIL CACHE
echo ============================================================
echo.

taskkill /f /im explorer.exe >nul 2>&1

del /f /s /q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*" >nul 2>&1

start explorer.exe

echo Thumbnail cache cleared successfully.
echo.
pause
