
@echo off
title Empty Recycle Bin
color 0B
cls

echo ============================================================
echo                  EMPTY RECYCLE BIN
echo ============================================================
echo.

echo Cleaning Recycle Bin...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"Clear-RecycleBin -Force -ErrorAction SilentlyContinue"

echo Recycle Bin cleanup completed.
echo.
pause
