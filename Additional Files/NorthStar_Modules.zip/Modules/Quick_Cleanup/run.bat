
@echo off
title Quick Cleanup
color 0B
cls

echo ============================================================
echo                    QUICK CLEANUP
echo ============================================================
echo.

echo [1/4] Clearing temporary files...
del /f /s /q "%temp%\*" >nul 2>&1
del /f /s /q "C:\Windows\Temp\*" >nul 2>&1

echo [2/4] Clearing thumbnail cache...
taskkill /f /im explorer.exe >nul 2>&1
del /f /s /q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*" >nul 2>&1
start explorer.exe

echo [3/4] Flushing DNS cache...
ipconfig /flushdns >nul

echo [4/4] Emptying Recycle Bin...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"Clear-RecycleBin -Force -ErrorAction SilentlyContinue"

echo.
echo ============================================================
echo Cleanup Completed Successfully
echo ============================================================
echo.
echo Safe maintenance tasks completed.
echo.
pause
