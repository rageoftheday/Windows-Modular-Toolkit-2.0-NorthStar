@echo off
title Psmod Excel
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
