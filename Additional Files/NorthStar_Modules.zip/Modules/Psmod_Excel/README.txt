Psmod Excel

Rebuilt from original label :psmod_excel.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
