# ============================================================
# PSMOD EXCEL
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PSMOD EXCEL" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Install-Module -Name ImportExcel -Force -AllowClobber

}
