# ============================================================
# CLEAR PREFETCH
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CLEAR PREFETCH" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Clearing Prefetch cache...'
    Write-Host '  Removes prefetch files Windows uses to speed up app'
    Write-Host '  launches. Windows will rebuild them automatically.'
    Write-Host '  Apps may launch slightly slower once after clearing.'
    cmd.exe /c "del /q /f `"C:\Windows\Prefetch\*`" >nul 2>&1"
    Write-Host 'Done.'
    Write-Host ""

}
