Clear Prefetch

Rebuilt from original label :clear_prefetch.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
