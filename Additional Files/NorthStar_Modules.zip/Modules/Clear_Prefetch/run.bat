@echo off
title Clear Prefetch
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
