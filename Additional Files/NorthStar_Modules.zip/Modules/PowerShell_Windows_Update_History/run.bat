@echo off
title PowerShell Windows Update History
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
