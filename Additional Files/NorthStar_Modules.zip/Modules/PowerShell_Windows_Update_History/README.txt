PowerShell Windows Update History

Rebuilt from original label :ps_wu_history.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
