# ============================================================
# POWERSHELL WINDOWS UPDATE HISTORY
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL WINDOWS UPDATE HISTORY" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "POWERSHELL WINDOWS UPDATE HISTORY"

    if (-not (Get-Module PSWindowsUpdate -ListAvailable)) {
        Write-Host "PSWindowsUpdate is not installed." -ForegroundColor Yellow
        return
    }

    Import-Module PSWindowsUpdate

    Get-WUHistory |
        Select-Object Date, KB, Title, Result |
        Format-Table -AutoSize
}
