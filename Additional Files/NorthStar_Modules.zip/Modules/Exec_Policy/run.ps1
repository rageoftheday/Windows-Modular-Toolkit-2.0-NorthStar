# ============================================================
# EXEC POLICY
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "EXEC POLICY" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host '------------------------------------------------------------'
    Write-Host '          POWERHELL EXECUTION POLICY'
    Write-Host '------------------------------------------------------------'
    Write-Host ""
    Write-Host 'PowerShell Execution Policy:'
    Write-Host '  Controls whether PowerShell scripts can run on this'
    Write-Host '  machine.'
    Write-Host '  Restricted   = no scripts allowed (default)'
    Write-Host '  RemoteSigned = local scripts run, downloads require signature'
    Write-Host '  AllSigned    = all scripts require signature'
    Write-Host ""
    Write-Host ""
    $f = Join-Path $env:TEMP 'execpol.ps1'
    Set-Content -Path $f -Value 'Get-ExecutionPolicy -List | Format-Table' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ' 1. Set to RemoteSigned (recommended for IT use)'
    Write-Host ' 2. Set to Restricted (locks down scripts)'
    Write-Host ' 3. Back to menu'
    Write-Host ""
    $epol = Read-Host 'Select:'
    cmd.exe /c "if `"$epol`"==`"1`" ("
    cmd.exe /c "powershell -NoProfile -Command `"Set-ExecutionPolicy RemoteSigned -Force; Write-Host 'SUCCESS: Permanent policy set to RemoteSigned.' -ForegroundColor Green`""
    cmd.exe /c ")"
    cmd.exe /c "if `"$epol`"==`"2`" ("
    cmd.exe /c "powershell -NoProfile -Command `"Set-ExecutionPolicy Restricted -Force; Write-Host 'SUCCESS: Permanent policy set to Restricted.' -ForegroundColor Green`""
    cmd.exe /c ")"
    Write-Host ""

}
