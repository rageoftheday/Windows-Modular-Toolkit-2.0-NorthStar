@echo off
title Exec Policy
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
