Exec Policy

Rebuilt from original label :exec_policy.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
