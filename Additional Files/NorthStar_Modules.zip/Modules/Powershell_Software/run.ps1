# ============================================================
# POWERSHELL SOFTWARE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL SOFTWARE" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'All Installed Software:'
    Write-Host '  Lists every program installed on this machine from both'
    Write-Host '  32-bit and 64-bit registry locations. Useful for'
    Write-Host '  software audits or finding installed versions.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'software.ps1'
    Set-Content -Path $f -Value 'Get-ItemProperty ''HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'',''HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'' -ErrorAction SilentlyContinue |' -Encoding UTF8
    Add-Content -Path $f -Value 'Where-Object {$_.DisplayName} |' -Encoding UTF8
    Add-Content -Path $f -Value 'Select-Object DisplayName,DisplayVersion,Publisher,InstallDate |' -Encoding UTF8
    Add-Content -Path $f -Value 'Sort-Object DisplayName | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
