Powershell Software

Rebuilt from original label :ps_software.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
