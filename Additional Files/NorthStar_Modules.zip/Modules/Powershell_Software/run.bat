@echo off
title Powershell Software
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
