@echo off
title Setup Depcheck Tools
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
