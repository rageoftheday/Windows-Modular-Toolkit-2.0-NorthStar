Setup Depcheck Tools

Rebuilt from original label :setup_depcheck_tools.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
