# ============================================================
# SETUP DEPCHECK TOOLS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "SETUP DEPCHECK TOOLS" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Checking Installed Tools (winget packages + PowerShell modules)...'
    Write-Host ""
    $f = Join-Path $env:TEMP 'depcheck_tools.ps1'
    Set-Content -Path $f -Value '$pass = 0; $fail = 0' -Encoding UTF8
    Add-Content -Path $f -Value 'function Show($label, $ok) {' -Encoding UTF8
    Add-Content -Path $f -Value 'if ($ok) { Write-Host (''[PASS]  '' + $label) -ForegroundColor Green; $script:pass++ }' -Encoding UTF8
    Add-Content -Path $f -Value 'else     { Write-Host (''[FAIL]  '' + $label) -ForegroundColor Red;  $script:fail++ }' -Encoding UTF8
    Add-Content -Path $f -Value '}' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''============================'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host '' INSTALLED TOOLS CHECK'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''============================'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- WINGET PACKAGES ---'' -ForegroundColor White' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''winget available''        ([bool](Get-Command winget -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''LibreHardwareMonitor''    ([bool](Get-Command LibreHardwareMonitor -EA SilentlyContinue) -or (Test-Path "$env:ProgramFiles\LibreHardwareMonitor\LibreHardwareMonitor.exe"))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''Sysinternals (psexec)''   ([bool](Get-Command psexec -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''Nmap''                    ([bool](Get-Command nmap -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''Git''                     ([bool](Get-Command git -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''7-Zip''                   ([bool](Get-Command 7z -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''Notepad++''               (Test-Path "$env:ProgramFiles\Notepad++\notepad++.exe")' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''WinDirStat''              (Test-Path "${env:ProgramFiles(x86)}\WinDirStat\windirstat.exe")' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- POWERSHELL MODULES ---'' -ForegroundColor White' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''PSWindowsUpdate''         ([bool](Get-Module PSWindowsUpdate -ListAvailable -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''ImportExcel''             ([bool](Get-Module ImportExcel -ListAvailable -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Show ''Carbon''                  ([bool](Get-Module Carbon -ListAvailable -EA SilentlyContinue))' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''============================'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'if ($fail -eq 0) { Write-Host ('' RESULT: All '' + $pass + '' tools present.'') -ForegroundColor Green }' -Encoding UTF8
    Add-Content -Path $f -Value 'else             { Write-Host ('' RESULT: '' + $pass + '' passed, '' + $fail + '' missing. Run Section 0 options 3-14 to install.'') -ForegroundColor Yellow }' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''============================'' -ForegroundColor Cyan' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    cmd.exe /c "if errorlevel 1 echo [FAIL] PowerShell execution failed"
    Write-Host ""
    Write-Host ""

}
