@echo off
title Powershell Privs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
