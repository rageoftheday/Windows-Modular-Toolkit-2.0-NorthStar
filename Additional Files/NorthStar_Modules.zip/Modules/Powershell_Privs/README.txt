Powershell Privs

Rebuilt from original label :ps_privs.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
