# ============================================================
# POWERSHELL PRIVS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL PRIVS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Current User Privileges:'
    Write-Host '  Shows the full token for the current user including'
    Write-Host '  group memberships and privileges. Running as admin'
    Write-Host '  will show elevated privileges enabled.'
    Write-Host ""
    cmd.exe /c "whoami /all"
    Write-Host ""
    Write-Host ""

}
