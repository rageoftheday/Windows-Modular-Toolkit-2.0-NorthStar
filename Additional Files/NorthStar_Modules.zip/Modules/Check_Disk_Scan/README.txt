Check Disk Scan

Rebuilt from original label :chkdsk_scan.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
