@echo off
title Check Disk Scan
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
