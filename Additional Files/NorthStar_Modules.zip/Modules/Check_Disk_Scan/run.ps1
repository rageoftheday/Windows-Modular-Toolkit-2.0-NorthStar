# ============================================================
# CHECK DISK SCAN
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "CHECK DISK SCAN" `
    -RequiresAdmin $true `
    -ScriptBlock {

    Write-Host "Running CHKDSK scan only, no changes..."
    Write-Host "Checks the drive file system for errors."
    Write-Host ""

    $chkdrive = Read-Host "Enter drive letter to scan (default: C)"

    if ([string]::IsNullOrWhiteSpace($chkdrive)) {
        $chkdrive = "C"
    }

    $chkdrive = $chkdrive.TrimEnd(":")

    Write-Host ""
    chkdsk "${chkdrive}:"
    Write-Host ""

    Write-Host "If errors were found, run Check Disk Fix to schedule a repair."
    Write-Host ""
}
