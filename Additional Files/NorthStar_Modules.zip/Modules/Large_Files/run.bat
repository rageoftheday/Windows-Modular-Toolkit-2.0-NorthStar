@echo off
title Large Files
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
