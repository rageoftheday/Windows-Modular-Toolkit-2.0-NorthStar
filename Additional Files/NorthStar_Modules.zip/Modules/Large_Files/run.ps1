# ============================================================
# LARGE FILES
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "LARGE FILES" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Show-ToolkitHeader "LARGE FILES"

    $Path = Read-Host "Folder to scan (blank = C:\Users)"
    if ([string]::IsNullOrWhiteSpace($Path)) {
        $Path = "C:\Users"
    }

    $MinimumMB = Read-Host "Minimum size in MB (blank = 500)"
    if ([string]::IsNullOrWhiteSpace($MinimumMB)) {
        $MinimumMB = 500
    }

    Write-Host ""
    Write-Host "Scanning $Path for files larger than $MinimumMB MB..." -ForegroundColor Cyan
    Write-Host ""

    Get-ChildItem $Path -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Length -ge ([int64]$MinimumMB * 1MB) } |
        Sort-Object Length -Descending |
        Select-Object @{Name="SizeMB";Expression={[math]::Round($_.Length / 1MB, 2)}}, FullName |
        Format-Table -AutoSize

    Write-Host ""
    Pause-Toolkit
}
