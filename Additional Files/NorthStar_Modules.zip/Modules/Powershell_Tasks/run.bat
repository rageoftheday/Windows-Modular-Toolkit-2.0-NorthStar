@echo off
title Powershell Tasks
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
