Powershell Tasks

Rebuilt from original label :ps_tasks.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
