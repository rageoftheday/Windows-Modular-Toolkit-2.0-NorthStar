# ============================================================
# POWERSHELL TASKS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL TASKS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Scheduled Tasks - Non-Microsoft, Enabled:'
    Write-Host '  Shows scheduled tasks not from Microsoft that are'
    Write-Host '  currently active. Third-party software often adds'
    Write-Host '  tasks here. Useful for finding unwanted or suspicious'
    Write-Host '  scheduled activity.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'tasks.ps1'
    Set-Content -Path $f -Value 'Get-ScheduledTask | Where-Object {$_.State -ne ''Disabled'' -and $_.TaskPath -notlike ''\Microsoft*''} |' -Encoding UTF8
    Add-Content -Path $f -Value 'Select-Object TaskName,TaskPath,State | Format-Table -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
