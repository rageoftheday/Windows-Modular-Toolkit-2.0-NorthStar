Powershell Defender

Rebuilt from original label :ps_defender.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
