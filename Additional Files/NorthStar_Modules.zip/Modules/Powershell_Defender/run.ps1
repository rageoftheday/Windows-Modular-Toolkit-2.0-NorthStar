# ============================================================
# POWERSHELL DEFENDER
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL DEFENDER" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Windows Defender Status:'
    Write-Host '  Shows whether Defender antivirus, antispyware, and real-'
    Write-Host '  time protection are active, plus the last signature'
    Write-Host '  update date. Out of date signatures reduce protection.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'defender.ps1'
    Set-Content -Path $f -Value 'Get-MpComputerStatus | Select-Object AMServiceEnabled,AntispywareEnabled,AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated,QuickScanStartTime | Format-List' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
