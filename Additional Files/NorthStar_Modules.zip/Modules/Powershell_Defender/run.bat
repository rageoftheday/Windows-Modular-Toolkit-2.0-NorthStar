@echo off
title Powershell Defender
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
