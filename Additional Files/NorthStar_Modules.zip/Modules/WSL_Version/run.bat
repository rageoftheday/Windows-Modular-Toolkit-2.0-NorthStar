@echo off
title WSL Version
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
