WSL Version

Rebuilt from original label :wsl_version.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
