# ============================================================
# WSL VERSION
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "WSL VERSION" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host '------------------------------------------------------------'
    Write-Host 'WSL VERSION'
    Write-Host '------------------------------------------------------------'
    Write-Host ""
    cmd.exe /c "wsl --version 2>nul"
    cmd.exe /c "if errorlevel 1 ("
    Write-Host 'WSL not available or not installed.'
    cmd.exe /c ")"
    Write-Host ""
    Write-Host ""

}
