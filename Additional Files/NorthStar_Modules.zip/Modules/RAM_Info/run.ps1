# ============================================================
# RAM INFO
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "RAM INFO" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Write-Host "--- MEMORY SUMMARY ---" -ForegroundColor Cyan

    Get-CimInstance Win32_ComputerSystem |
        Select-Object `
            @{N="TotalRAMGB";E={[math]::Round($_.TotalPhysicalMemory / 1GB, 2)}} |
        Format-Table -AutoSize

    Write-Host "--- MEMORY MODULES ---" -ForegroundColor Cyan

    Get-CimInstance Win32_PhysicalMemory |
        Select-Object `
            BankLabel,
            Manufacturer,
            PartNumber,
            Speed,
            @{N="CapacityGB";E={[math]::Round($_.Capacity / 1GB, 2)}} |
        Format-Table -AutoSize
}
