RAM Info

Rebuilt from original label :ram_info.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
