@echo off
title View Running Services
color 0B
cls
echo ============================================================
echo View Running Services
echo ============================================================
echo.
echo Displays running Windows services.
echo.
echo Demo module executed successfully.
echo.
pause
