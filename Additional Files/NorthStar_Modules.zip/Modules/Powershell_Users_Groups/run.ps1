# ============================================================
# POWERSHELL USERS GROUPS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL USERS GROUPS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Local Users and Groups:'
    Write-Host '  Lists all local user accounts with last logon time and'
    Write-Host '  password status, plus all local security groups.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'usersgroups.ps1'
    Set-Content -Path $f -Value 'Write-Host ''--- LOCAL USERS ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-LocalUser | Format-Table Name,Enabled,LastLogon,PasswordRequired,PasswordExpires -AutoSize' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''''' -Encoding UTF8
    Add-Content -Path $f -Value 'Write-Host ''--- LOCAL GROUPS ---'' -ForegroundColor Cyan' -Encoding UTF8
    Add-Content -Path $f -Value 'Get-LocalGroup | Format-Table Name,Description -AutoSize' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
