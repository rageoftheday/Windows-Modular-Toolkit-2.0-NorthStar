@echo off
title Powershell Users Groups
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
