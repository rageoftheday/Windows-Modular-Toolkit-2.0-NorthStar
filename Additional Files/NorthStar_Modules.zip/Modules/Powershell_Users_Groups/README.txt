Powershell Users Groups

Rebuilt from original label :ps_users_groups.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
