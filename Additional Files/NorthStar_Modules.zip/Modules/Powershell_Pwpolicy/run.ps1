# ============================================================
# POWERSHELL PWPOLICY
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL PWPOLICY" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Local Password Policy:'
    Write-Host '  Shows password length requirements, complexity rules,'
    Write-Host '  lockout thresholds, and expiry settings for local accounts.'
    Write-Host '  Domain password policy is set via Group Policy instead.'
    Write-Host ""
    cmd.exe /c "net accounts"
    Write-Host ""
    Write-Host ""

}
