Powershell Pwpolicy

Rebuilt from original label :ps_pwpolicy.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
