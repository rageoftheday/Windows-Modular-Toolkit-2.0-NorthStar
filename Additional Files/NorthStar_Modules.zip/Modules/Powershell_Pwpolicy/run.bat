@echo off
title Powershell Pwpolicy
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
