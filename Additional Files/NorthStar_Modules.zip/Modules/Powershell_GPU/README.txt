Powershell GPU

Rebuilt from original label :ps_gpu.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
