# ============================================================
# POWERSHELL GPU
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL GPU" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'GPU Information:'
    Write-Host '  Shows the graphics adapter details including VRAM,'
    Write-Host '  driver version, and current display resolution.'
    Write-Host '  Check driver version here before updating GPU drivers.'
    Write-Host ""
    $f = Join-Path $env:TEMP 'gpuinfo.ps1'
    Set-Content -Path $f -Value 'Get-CimInstance Win32_VideoController | Format-List Name,VideoProcessor,@{N=''VRAM(GB)'';E={[math]::Round($_.AdapterRAM/1GB,1)}},DriverVersion,DriverDate,VideoModeDescription,Status' -Encoding UTF8
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $f
    Write-Host ""
    Write-Host ""

}
