@echo off
title Powershell GPU
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
