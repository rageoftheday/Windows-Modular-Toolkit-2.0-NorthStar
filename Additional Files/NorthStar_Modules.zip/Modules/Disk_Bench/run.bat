@echo off
title Disk Bench
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
