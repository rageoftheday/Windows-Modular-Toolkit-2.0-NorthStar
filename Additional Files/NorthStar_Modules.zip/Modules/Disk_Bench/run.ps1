# ============================================================
# DISK BENCH
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "DISK BENCH" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Disk Benchmark using Windows System Assessment Tool:'
    Write-Host '  Runs a read speed test on the specified drive using the'
    Write-Host '  built-in winsat tool. Gives a rough performance score.'
    Write-Host '  Useful for baseline comparisons or spotting degraded SSDs.'
    Write-Host ""
    $benchdrive = Read-Host 'Enter drive letter to benchmark (default: C):'
    cmd.exe /c "if `"$benchdrive`"==`"`" set `"benchdrive=C`""
    Write-Host ""
    cmd.exe /c "winsat disk -drive $benchdrive"
    Write-Host ""
    Write-Host ""

}
