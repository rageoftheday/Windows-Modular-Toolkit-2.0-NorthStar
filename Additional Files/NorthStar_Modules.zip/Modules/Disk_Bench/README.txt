Disk Bench

Rebuilt from original label :disk_bench.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
