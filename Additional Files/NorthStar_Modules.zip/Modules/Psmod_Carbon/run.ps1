# ============================================================
# PSMOD CARBON
# Native PowerShell module
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "PSMOD CARBON" `
    -RequiresAdmin $false `
    -ScriptBlock {

    Install-Module -Name Carbon -Force -AllowClobber

}
