Psmod Carbon

Rebuilt from original label :psmod_carbon.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
