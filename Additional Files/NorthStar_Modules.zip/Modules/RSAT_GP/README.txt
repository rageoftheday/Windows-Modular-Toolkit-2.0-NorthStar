RSAT GP

Rebuilt from original label :rsat_gp.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
