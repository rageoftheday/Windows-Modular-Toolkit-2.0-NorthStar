@echo off
title RSAT GP
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
