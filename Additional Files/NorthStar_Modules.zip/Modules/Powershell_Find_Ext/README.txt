Powershell Find Ext

Rebuilt from original label :ps_find_ext.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
