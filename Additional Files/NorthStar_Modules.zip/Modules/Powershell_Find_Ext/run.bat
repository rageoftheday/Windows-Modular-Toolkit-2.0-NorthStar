@echo off
title Powershell Find Ext
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
