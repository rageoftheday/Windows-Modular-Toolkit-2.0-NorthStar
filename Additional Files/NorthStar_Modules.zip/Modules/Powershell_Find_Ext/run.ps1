# ============================================================
# POWERSHELL FIND EEXTENSION
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL FIND EXTENSION" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $Path = Read-Host "Enter folder path to search"
    $Ext  = Read-Host "Enter file extension (example: .log or txt)"

    if ([string]::IsNullOrWhiteSpace($Path) -or !(Test-Path $Path)) {
        Write-Host "Invalid path." -ForegroundColor Red
        return
    }

    if ([string]::IsNullOrWhiteSpace($Ext)) {
        Write-Host "Invalid extension." -ForegroundColor Red
        return
    }

    # Normalize extension
    if ($Ext -notmatch "^\.") {
        $Ext = ".$Ext"
    }

    Write-Host ""
    Write-Host "Results for *$Ext in $Path" -ForegroundColor Cyan
    Write-Host ""

    Get-ChildItem `
        -Path $Path `
        -Recurse `
        -Filter "*$Ext" `
        -File `
        -ErrorAction SilentlyContinue |
    Select-Object `
        FullName,
        @{N="Size(MB)";E={[math]::Round($_.Length/1MB,2)}},
        LastWriteTime |
    Format-Table -AutoSize

    Write-Host ""
}