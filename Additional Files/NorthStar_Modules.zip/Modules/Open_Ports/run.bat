@echo off
title Open Ports
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
