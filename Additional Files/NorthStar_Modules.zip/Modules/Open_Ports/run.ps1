# ============================================================
# OPEN PORTS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "OPEN PORTS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Active Listening Ports and Connections:'
    Write-Host '  Shows which ports are open and listening for connections,'
    Write-Host '  and all active network connections with process IDs.'
    Write-Host '  Useful for spotting unexpected open ports or connections.'
    Write-Host ""
    Write-Host '--- LISTENING PORTS ---'
    cmd.exe /c "netstat -ano | findstr `"LISTENING`""
    Write-Host ""
    Write-Host '--- ALL ACTIVE CONNECTIONS ---'
    cmd.exe /c "netstat -ano"
    Write-Host ""
    Write-Host ""

}
