Open Ports

Rebuilt from original label :open_ports.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
