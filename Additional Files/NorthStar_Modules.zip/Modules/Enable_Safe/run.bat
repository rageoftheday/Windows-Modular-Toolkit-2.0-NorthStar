@echo off
title Enable Safe
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
