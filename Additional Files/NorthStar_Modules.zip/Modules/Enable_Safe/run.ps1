# ============================================================
# ENABLE SAFE
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "ENABLE SAFE" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    $smconfirm = Read-Host 'Enable Safe Mode? (Y/N):'
    cmd.exe /c "if /i `"!smconfirm!`" NEQ `"Y`" goto safemode_toggle"
    cmd.exe /c "bcdedit /set {current} safeboot minimal"
    cmd.exe /c "if errorlevel 1 ("
    Write-Host 'ERROR: Run as Administrator!'
    cmd.exe /c ") else ("
    Write-Host 'Safe Mode ENABLED. Reboot required.'
    cmd.exe /c ")"
    Write-Host ""

}
