Enable Safe

Rebuilt from original label :enable_safe.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
