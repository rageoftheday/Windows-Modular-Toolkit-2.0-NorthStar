Kernel Drivers

Rebuilt from original label :kernel_drivers.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
