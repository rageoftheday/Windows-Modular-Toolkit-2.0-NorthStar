# ============================================================
# KERNEL DRIVERS
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "KERNEL DRIVERS" `
    -RequiresAdmin $false `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'All Loaded Kernel Drivers:'
    Write-Host '  Lists every driver loaded into the Windows kernel with'
    Write-Host '  signature status. Unsigned or suspicious drivers can'
    Write-Host '  cause instability. Compare with the appropriate validator module for third-party'
    Write-Host '  drivers specifically.'
    Write-Host ""
    cmd.exe /c "driverquery /FO table /SI 2>nul"
    Write-Host ""
    Write-Host ""

}
