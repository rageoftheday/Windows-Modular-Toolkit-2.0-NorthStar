@echo off
title Powershell Start Svc
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
