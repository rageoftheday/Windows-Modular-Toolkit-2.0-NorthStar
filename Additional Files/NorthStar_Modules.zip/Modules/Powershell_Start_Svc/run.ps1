# ============================================================
# POWERSHELL START SVC
# Native launcher converted from rebuilt legacy payload
# ============================================================

$Root = Resolve-Path "$PSScriptRoot\..\.."
. "$Root\core\bootstrap.ps1"

Invoke-ToolkitModule `
    -ModuleName "POWERSHELL START SVC" `
    -RequiresAdmin $true `
    -ScriptBlock {

    $ErrorActionPreference = "Continue"
    Write-Host 'Start a Stopped Service by Name:'
    Write-Host '  Starts a service that is currently stopped. Use the'
    Write-Host '  short service name. Find names via the appropriate validator module.'
    Write-Host ""
    $startsvc = Read-Host 'Enter service name to start:'
    Write-Host ""
    cmd.exe /c "powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command `"Start-Service -Name '$startsvc' -ErrorAction SilentlyContinue; Write-Host 'Service started.' -ForegroundColor Green`""
    Write-Host ""
    Write-Host ""

}
