Powershell Start Svc

Rebuilt from original label :ps_start_svc.
Old menu/goto/call flow was removed.
Review legacy.bat before using in production.
